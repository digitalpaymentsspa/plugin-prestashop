<?php

namespace PrestaShop\Module\Fpay\Environment;

use PrestaShop\Module\Fpay\Contracts\Environment\FpayEnvEnvironment;

/**
 * Allow to set the differents api key / api link depending on
 */
class FpayEnv extends Env implements FpayEnvEnvironment
{
    private $apiUrl;
    private $countryCode;
    private $currency;
    private $documentType;
    private $paymentMethod;
    private $version;
    private $pstOrigen;
    private $softDescriptor;
    private $merchantFantasyName;
    private $invoiceType;
    private $shippingMethod;
    private $channel;


    public function __construct()
    {
        parent::__construct();
        $this->getMode() ? $this->apiUrl = $_ENV['FPAY_API_TEST_URL'] : $this->apiUrl = $_ENV['FPAY_API_PROD_URL'];
        $this->countryCode = $_ENV['FPAY_COUNTRY_CODE'];
        $this->currency = $_ENV['FPAY_CURRENCY'];
        $this->documentType = $_ENV['FPAY_DOCUMENT_TYPE'];
        $this->version = $_ENV['FPAY_VERSION'];
        $this->paymentMethod = $_ENV['FPAY_PAYMENT_METHOD'];
        $this->pstOrigen = $_ENV['FPAY_PST_ORIGEN'];
        $this->softDescriptor = $_ENV['FPAY_SOFT_DESCRIPTOR'];
        $this->merchantFantasyName = $_ENV['FPAY_MERCHANT_FANTASY_NAME'];
        $this->invoiceType = $_ENV['FPAY_INVOICE_TYPE'];
        $this->shippingMethod = $_ENV['FPAY_SHIPPING_METHOD'];
        $this->channel = $_ENV['FPAY_CHANNEL'];
    }

    public function getApiUrl()
    {
        return $this->apiUrl;
    }

    public function getCountryCode()
    {
        return mb_strtolower($this->countryCode);
    }

    public function getCurrency()
    {
        return $this->currency;
    }

    public function getDocumentType()
    {
        return $this->documentType;
    }

    public function getPaymentMethod()
    {
        return $this->paymentMethod;
    }

    public function getPstOrigen()
    {
        return $this->pstOrigen;
    }

    public function getVersion()
    {
        return $this->version;
    }

    public function getSoftDescriptor()
    {
        return $this->softDescriptor;
    }

    public function getMerchantFantasyName()
    {
        return $this->merchantFantasyName;
    }

    public function getInvoiceType()
    {
        return $this->invoiceType;
    }

    public function getShippingMethod()
    {
        return $this->shippingMethod;
    }

    public function getChannel()
    {
        return $this->channel;
    }
}
