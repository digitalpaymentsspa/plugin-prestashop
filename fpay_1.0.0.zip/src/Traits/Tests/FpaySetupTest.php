<?php 

declare(strict_types=1);

namespace PrestaShop\Module\Fpay\Traits\Tests;

use PrestaShop\Module\Fpay\Classes\FpayCore;

trait FpaySetupTest{
    
    public function testGetPhpVersion()
    {
        $this->assertIsString($this->fpay->getPhpVersion());
    }

    public function testHasCurlExt()
    {
        $this->assertIsBool($this->fpay->hasCurlExt());
    }

    public function testPhpVersionValidateWhenPhpversionIsDeprecated()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->disableOriginalConstructor()
            ->onlyMethods(['getPhpVersion'])
            ->getMock();

        $mock->expects($this->any())
            ->method('getPhpVersion')
            ->will($this->returnValue('5.4'));

        $this->assertFalse($mock->phpVersionValidate());
    }

    public function testPhpVersionValidateWhenPhpversionIsSupported()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->disableOriginalConstructor()
            ->onlyMethods(['getPhpVersion'])
            ->getMock();

        $mock->expects($this->any())
            ->method('getPhpVersion')
            ->will($this->returnValue('7.4'));

        $mock->limited_countries = ['CL'];

        $this->assertTrue($mock->phpVersionValidate());
    }

    public function testPreInstallValidationCountryNotSupported()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->disableOriginalConstructor()
            ->onlyMethods(['phpVersionValidate'])
            ->getMock();

        $mock->expects($this->any())
            ->method('phpVersionValidate')
            ->will($this->returnValue(true));

        $this->assertFalse($mock->preInstallValidation());
    }

    public function testPreInstallValidationNoCurl()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->disableOriginalConstructor()
            ->onlyMethods(['phpVersionValidate', 'hasCurlExt'])
            ->getMock();

        $mock->expects($this->any())
            ->method('phpVersionValidate')
            ->will($this->returnValue(true));

        $mock->expects($this->any())
            ->method('hasCurlExt')
            ->will($this->returnValue(false));

        $this->assertFalse($mock->preInstallValidation());
    }

    public function testPreInstallValidationIsTrue()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->disableOriginalConstructor()
            ->onlyMethods(['phpVersionValidate'])
            ->getMock();

        $mock->expects($this->any())
            ->method('phpVersionValidate')
            ->will($this->returnValue(true));

        $mock->limited_countries = ['CL'];

        $this->assertTrue($mock->preInstallValidation());
    }

    public function testPreInstallValidationIsFalse()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->disableOriginalConstructor()
            ->onlyMethods(['phpVersionValidate'])
            ->getMock();

        $mock->expects($this->any())
            ->method('phpVersionValidate')
            ->will($this->returnValue(false));

        $this->assertFalse($mock->preInstallValidation());
    }

    public function testParentInstall()
    {
        $this->assertIsBool($this->fpay->parentInstall());
    }

    public function testInstallFailed()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->disableOriginalConstructor()
            ->onlyMethods(['parentInstall', 'preInstallValidation'])
            ->getMock();

        $mock->expects($this->any())
            ->method('parentInstall')
            ->will($this->returnValue(true));

        $mock->expects($this->any())
            ->method('preInstallValidation')
            ->will($this->returnValue(false));

        $this->assertFalse($mock->install());
    }

    public function testDropFpayTableIfExist()
    {
        $this->assertIsBool($this->fpay->dropFpayTableIfExist());
    }

    public function testCreateFpayTable()
    {
        $this->assertIsBool($this->fpay->createFpayTable());
    }

    public function testInstallSuccess()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->disableOriginalConstructor()
            ->onlyMethods([
                'parentInstall', 
                'preInstallValidation', 
                'registerHook', 
                'installDB', 
                'installFpayOrderState'
            ])
            ->getMock();

        $mock->expects($this->any())
            ->method('parentInstall')
            ->will($this->returnValue(true));

        $mock->expects($this->any())
            ->method('installFpayOrderState')
            ->will($this->returnValue(true));

        $mock->expects($this->any())
            ->method('installDB')
            ->will($this->returnValue(true));

        $mock->expects($this->any())
            ->method('preInstallValidation')
            ->will($this->returnValue(true));

        $mock->expects($this->any())
            ->method('registerHook')
            ->will($this->returnValue(true));

        $this->assertTrue($mock->install());
    }

    public function testInstallDBisSuccess()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->onlyMethods(['dropFpayTableIfExist', 'createFpayTable'])
            ->getMock();

        $mock->expects($this->any())
            ->method('dropFpayTableIfExist')
            ->will($this->returnValue(true));

        $mock->expects($this->any())
            ->method('createFpayTable')
            ->will($this->returnValue(true));

        $this->assertTrue($mock->installDB());
    }

    public function testInstallDBDropTableFailed()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->onlyMethods(['dropFpayTableIfExist'])
            ->getMock();

        $mock->expects($this->any())
            ->method('dropFpayTableIfExist')
            ->will($this->returnValue(false));

        $this->assertFalse($mock->installDB());
    }

    public function testInstallDBCreateTableFailed()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->onlyMethods(['createFpayTable', 'dropFpayTableIfExist'])
            ->getMock();

        $mock->expects($this->any())
            ->method('dropFpayTableIfExist')
            ->will($this->returnValue(true));

        $mock->expects($this->any())
            ->method('createFpayTable')
            ->will($this->returnValue(false));

        $this->assertFalse($mock->installDB());
    }

    public function testHasFpayOrderState()
    {
        $this->assertIsBool((bool)$this->fpay->hasFpayOrderState());
    }

    public function testInstallFpayOrderStateAddOrderFailed()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->onlyMethods(['hasFpayOrderState'])
            ->getMock();

        $mock->expects($this->any())
            ->method('hasFpayOrderState')
            ->will($this->returnValue(false));

        $this->assertIsBool($mock->installFpayOrderState());
    }

    public function testInstallFpayOrderState()
    {
        $mock = $this->getMockBuilder(FpayCore::class)
            ->onlyMethods(['hasFpayOrderState', 'addOrderState'])
            ->getMock();

        $mock->expects($this->any())
            ->method('hasFpayOrderState')
            ->will($this->returnValue(false));

        $mock->expects($this->any())
            ->method('addOrderState')
            ->will($this->returnValue(true));

        $this->assertIsBool($mock->installFpayOrderState());
    }

    public function testUninstall()
    {
        $this->fpay->unitTest = true;
        $this->assertIsBool($this->fpay->uninstall());
    }
}