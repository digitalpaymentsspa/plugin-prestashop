<?php

namespace PrestaShop\Module\Fpay\Traits;

use Address;
use Configuration;
use Context;
use Currency;
use Db;
use Order;
use PrestaShop\PrestaShop\Core\Domain\Order\CancellationActionType;
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

trait FpayHooks
{
    /**
     * Return order details
     *
     * @param array $params Hook parameters
     *
     * @return bool|void
     */
    public function hookActionOrderReturn($params)
    {
        if (!$this->active || !$this->checkCurrency($params['cart'])) {
            return false;
        }
    }

    /**
     * Return product and refunds
     *
     * @param array $params Hook parameters
     *
     * @return array|null
     */
    public function hookActionProductCancel($params)
    {
        // let's say you want to check what user action triggered the hook:
        $session = Context::getContext()->cookie;
        if ($session->__isset('fpayWebHookRefund')&&(bool)$session->fpayWebHookRefund===true){                        
            $session->__set('fpayWebHookRefund', '0');
            $session->write();
        }else{
            if ($this->active && in_array($params['action'], [CancellationActionType::STANDARD_REFUND, CancellationActionType::PARTIAL_REFUND])) {
                $this->fpayGatewayPayment->refundIntention($params['order'], round($params['cancel_amount']));
            }
        }
    }

    /**
     * Return order details
     *
     * @param array $params Hook parameters
     *
     * @return array|null
     */
    public function hookDisplayOrderDetail($params)
    {
        if (!$this->active || !$this->checkCurrency($params['cart'])) {
            return false;
        }
        $html = '';
        $session = Context::getContext()->cookie;
        if (isset($session->fpayError) && trim($session->fpayError) != '' && $session->fpayError != null) {
            $html = '<script> document.getElementById("order-infos").innerHTML += ';
            $html .= '`<div id="fpay-error">' . $this->displayError($session->fpayError) . '</div>`';
            $html .= '</script$>';
            $session->__set('fpayError','');
        }

        return $html;
    }


    public function hookDisplayBackOfficeHeader()
    {        
        $db = Db::getInstance(_PS_USE_SQL_SLAVE_);
        $pendingUpdate = $db->executeS("SELECT * FROM `" . _DB_PREFIX_ . "fpay`");
        $pendingUpdate && $this->fpayGatewayPayment->processPending() && !$this->unitTest ? exit() : null;
        if (strripos($_SERVER['REQUEST_URI'], 'modules/fpay/logs')!==false) {
            $this->context->controller ? $this->context->controller->addJquery() : null;
            $this->context->controller ? $this->context->controller->addJS(_MODULE_DIR_ . "fpay/templates/admin/logs/js/jquery.json-viewer.js") : null;
            $this->context->controller ? $this->context->controller->addJS(_MODULE_DIR_ . "fpay/templates/admin/logs/js/init-json-viewer.js") : null;
            $this->context->controller ? $this->context->controller->addCSS(_MODULE_DIR_ . "fpay/templates/admin/logs/css/jquery.json-viewer.css") : null;
        }        
    }

    /**
     * Return payment options available for PS 1.7+ 
     *
     * @param array $params Hook parameters
     *
     * @return array|null
     */
    public function hookPaymentOptions($params)
    {
        if (!$this->active || !$this->checkCurrency($params['cart'])) {
            return false;
        }
        $option = new PaymentOption();
        $option->setCallToActionText($this->l(''))
            ->setLogo(_MODULE_DIR_ . '/fpay/views/img/full_logo.png')
            ->setAction($this->context->link->getModuleLink($this->name, 'validation', array(), true))
            ->setAdditionalInformation($this->fetch('module:fpay/views/templates/hook/infos.tpl'));

        return [
            $option
        ];
    }

    /**
     * Get or create new PrestaShop order
     *
     * @param int|null $orderId
     * @return Order
     */
    public function getOrCreateOrder($orderId = null)
    {
        return new Order($orderId);
    }

    /**
     * Get or create new PrestaShop address delivery
     *
     * @param int|null $addressId
     * @return Address
     */
    public function getOrCreateAddress($addressId = null)
    {
        return new Address($addressId);
    }

    /**
     * Return payment
     *
     * @param array $params Hook parameters
     *
     * @return string
     */
    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return false;
        }

        if ($this->validateState($params['order']->getCurrentState())) {
            $url = $this->createIntention(
                $this->getOrCreateOrder((int)$params['order']->id),
                $this->getOrCreateAddress((int)$params['cart']->id_address_delivery)
            );
            if ($url != '') {
                header("Location: $url");
                $this->unitTest ? null : exit();
                return 'success';
            } else {
                $this->setSmartyFailed();
            }
        } else {
            $this->setSmartyFailed();
        }
        $this->context->controller ? $this->context->controller->registerStylesheet('fpay-styles', 'modules/' . $this->name . '/views/css/styles.css', ['media' => 'all','priority' => 200,]) : null;

        return $this->fetch('module:fpay/views/templates/payment_execution.tpl');
    }

    /**
     * Create intention in fpay
     *
     * @param Order $order
     * @param Address $address
     * @return string
     */
    public function createIntention(Order $order, Address $address)
    {
        return $this->fpayGatewayPayment->processPayment($order,$address);
    }

    /**
     * Set smarty data to failed
     *
     * @return void
     */
    private function setSmartyFailed()
    {
        $this->smarty->assign(
            array(
                'status' => 'failed',
                'contact_url' => $this->context->link->getPageLink('contact', true),
            )
        );
    }

    /**
     * validate if current state is in the allow states
     *
     * @param string $state
     * @return bool
     */
    public function validateState($state)
    {
        return in_array(
            $state,
            [
                Configuration::get('PS_OS_FPAY'),
                Configuration::get('PS_OS_OUTOFSTOCK'),
                Configuration::get('PS_OS_OUTOFSTOCK_UNPAID'),
            ]
        );
    }

     /**
     * Get or create new PrestaShop currency
     *
     * @param int|null $currencyId
     * @return Currency
     */
    public function getOrCreateCurrency($currencyId = null)
    {
        return new Currency($currencyId);
    }

    /**
     * Check if prestashop has a valid currency for the plugin 
     *
     * @param Cart|mixed $cart
     * @return bool
     */
    public function checkCurrency($cart)
    {
        $currencies_module = $this->getCurrency($cart->id_currency);
        $cart->id_currency = $this->unitTest ? $currencies_module[0]['id_currency'] : $cart->id_currency;
        $currency_order = $this->getOrCreateCurrency((int)$cart->id_currency);
        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }
}
