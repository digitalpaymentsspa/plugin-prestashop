<?php

namespace PrestaShop\Module\Fpay\Controllers;

use DateTime;
use PrestaShop\Module\Fpay\Forms\LogDate;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\Request;

class LogController extends FrameworkBundleAdminController
{

    public function getLogs(Request $request)
    {
        $form = $this->createForm(LogDate::class);
        $form->handleRequest($request);

        $date = date('Y-m-d');
        // logic of form handling
        if ($form->isSubmitted() && $form->isValid()) {
            $date = $form->get('date')->getData()->format('Y-m-d');
            $this->addFlash(
                'success',
                'Log obtenido con éxito.'
            );
        } else {
            $form->get('date')->setData(DateTime::createfromformat('Y-m-d', $date));
        }        
        $data = $this->setDataLog($date);        

        return $this->render(
            '@Modules/fpay/templates/admin/logs/logs.html.twig',
            [
                'data' => $data,
                'date' => $date,
                'form' => $form->createView()
            ]
        );
    }

    /**
     * Format log file
     *
     * @param string $date
     * @return array $data
     */
    private function setDataLog(string $date)
    {
        $data = [];        
        try {
            $url = _PS_MODULE_DIR_ . 'fpay/src/logs/log-' . $date . '.txt';
            $handle = fopen($url, "r");
            if ($handle) {
                while (($line = fgets($handle)) !== false) {
                    // process the line read.
                    if (trim($line)) {
                        $json = json_decode($line);
                        if (json_last_error() === JSON_ERROR_NONE) {
                            $data[] = ['type' => 'json', 'value' => json_encode($json)];
                        } else {
                            $data[] = ['type' => 'text', 'value' => $line];
                        }
                    }
                }
                fclose($handle);
            }
        } catch (\Throwable $th) {
            $data = [];
        }

        return $data;
    }
}
