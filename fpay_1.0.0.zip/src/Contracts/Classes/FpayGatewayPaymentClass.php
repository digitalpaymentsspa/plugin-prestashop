<?php

namespace PrestaShop\Module\Fpay\Contracts\Classes;

use Address;
use Order;
use OrderHistory;
use PrestaShopCollection;

interface FpayGatewayPaymentClass{
    /**
     * Process payment Process the data received by 
     * prestashop to make the payment with Fpay
     *
     * @param Order $orderId
     * @param Address $address
     * @return string $redirectUrl
     */
    public function processPayment(Order $order, Address $address);


    /**
     * get payment intention from Fpay
     *
     * @param string $intentionId
     * @return mixed
     */
    public function getIntention(string $intentionId);

    /**
     * Update pending intentions
     *
     * @return bool
     */
    public function processPending();

    /**
     * Get site url
     * @param bool $withoutPrestashop
     * @return string
     */
    public function getSiteUrl(bool $withoutPrestashop);

    /**
     * Set the data of the intention
     *
     * @param Order $order
     * @param Address $address
     * @param string $paymentSuccessUrl
     * @param string $paymentErrorUrl
     * @param array $items
     * @return array
     */
    public function setintentionData(Order $order, Address $address, array $items = []);

    /**
     * Set items for item_list of intention transaction data
     *
     * @param array $products
     * @return array $items
     */
    public function setItems(array $products);

    /**
     * Update prestashop payment information with the intention Id
     *
     * @param PrestaShopCollection $payment
     * @param string $intentionId
     * @return void
     */
    public function updatePaymentTransactionId(PrestaShopCollection $payment,string $intentionId);

    /**
     * Set order status according Fpay intention
     *
     * @param string $fpayState
     * @param Order $order
     * @param OrderHistory $history
     * @return void
     */
    public function setOrderStatus(string $fpayState,Order $order,OrderHistory $history);

    /**
     * Make refund to fpay
     *
     * @param Order $order
     * @param integer $refundedAmount
     * @return void
     */
    public function refundIntention(Order $order, int $refundedAmount);

    /**
     * Get refund amount
     *
     * @param mixed $fpayIntention
     * @return float
     */
    public function getRefundAmount($fpayIntention);

    /**
     * Create order status message for customer
     *
     * @param mixed|null $fpayIntention
     * @param Order $order
     * @param array $orderDetail
     * @param array|float $productAmountAndQuantity 
     * @return void
     */
    public function createMessage($fpayIntention, Order $order, $productAmountAndQuantity, array $orderDetail = [], string $extraDescription = '');

    /**
     * Add log Fpay Module Core link function
     *
     * @param string $data
     * @param boolean $currentDate
     * @param string $functionOrVar
     * @return void
     */
    public function addLog(string $data = '', bool $currentDate = false, string $functionOrVar = '', string $description = '');

    /**
     * Logger Fpay Module Core link function
     *
     * @return void
     */
    public function logger();
}