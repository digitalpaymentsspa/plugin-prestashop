<?php

declare(strict_types=1);

namespace Tests\Unit\Environment;

use PrestaShop\Module\Fpay\Environment\Env;
use Tests\BaseTest;

class EnvTest extends BaseTest
{
    
    protected Env $env;    

    protected function setUp(): void
    {
        $this->env = new Env();
    }

    /**
     * Check if class file exists
     *                                                                                                                                                                                                                  
     * @return void
     */
    public function testFileExists()
    {
        $filePath = _PS_MODULE_DIR_ . 'fpay/src/Environment/Env.php';
        $exists = file_exists($filePath);
        $this->assertTrue($exists);
    }
    
    public function testClassConstructor()
    {
        $this->assertInstanceOf(Env::class, $this->env);        
    }

    public function testGetName()
    {
        $this->assertIsString($this->env->getName());
    }
    
    public function testGetMode()
    {
        $this->assertIsBool($this->env->getMode());
    }
    
    public function testAddLog(): void
    {
        $this->env->addLog('unit test',true,'testAddLog','Test passed');
        $this->assertTrue(true);
    }
    
    public function testLogger()
    {
        $this->env->logger();
        $this->assertTrue(true);
    }
    
}
