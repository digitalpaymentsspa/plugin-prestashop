<?php

use PrestaShop\Module\Fpay\Classes\FpayCore;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/vendor/autoload.php';

class Fpay extends FpayCore
{              
    // The module codes have been transferred
    // to the "/classes/FpayCore.php" file.  
}
