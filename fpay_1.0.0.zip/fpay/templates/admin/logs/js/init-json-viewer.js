$(function () {
  $(".json-viewer").each(function () {
    $(this).jsonViewer( JSON.parse($(this).html()),{
      collapsed:true,
      withQuotes:true,
    });
  });
});
