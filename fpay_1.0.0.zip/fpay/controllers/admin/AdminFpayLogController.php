<?php

class AdminFpayLogController extends ModuleAdminController
{
    public $name = "AdminFpayLog";

    public function __construct()
	{
		parent::__construct();
		$this->bootstrap = true;
		$this->display = 'Test you Module';
		$this->meta_title = $this->l('Test Module');
	}

	public function viewAccess($disable = false)
	{
		return true;            
	}
	
	public function getFieldsValues()
	{
		return array(			
			'date' => Tools::getValue('date', date('Y-m-d')),			
		);
	}	

	protected function getFormFields()
	{
		return array(
			'form' => array(			
				'input' => array(					
					array(						
						'type' => 'date',
						'prefix' => '<i class="icon icon-calendar"></i>',
						'desc' => $this->l('Seleccione la fecha de los logs que desea ver.'),
						'name' => 'date',
						'label' => $this->l('Fecha'),
					),					
				),
				'submit' => array(
					'title' => $this->l('Consultar'),
					'icon' => 'database'
				),
			),
		);
	}	
	
	public function renderForm()
	{
		$helper = new HelperForm();
		$helper->show_toolbar = true;
		$helper->table = $this->table;
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->allow_employee_form_lang =
			Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$this->fields_form = array();
	 
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'submitFpayLog';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminFpayLog', false);
		$helper->token = Tools::getAdminTokenLite('AdminFpayLog');
		$helper->tpl_vars = array(
			'fields_value' => $this->getFieldsValues(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id,            
		);
	 
		$form = $helper->generateForm(array($this->getFormFields()));
		$form = str_replace('class="panel"','style="max-width:680px;margin-left: auto;margin-right: auto;"',$form);
		return $form;
	}		    

	public function renderList()
	{
		$form = $this->renderForm();

		// To load form inside your template		
		$this->context->smarty->assign(array(
			'form_tpl' => $form,
			'data' => $this->setDataLog(Tools::getValue('date', date('Y-m-d'))),
            'date' => Tools::getValue('date', date('Y-m-d'))
		));
		$this->context->smarty->assign('form_tpl', $form);
		return $this->context->smarty->fetch(_PS_MODULE_DIR_.'fpay/views/templates/admin/fpayLog.tpl');
	}

    /**
     * Format log file
     *
     * @param string $date
     * @return array $data
     */
    private function setDataLog(string $date)
    {
        $data = [];        
        try {
            $url = _PS_MODULE_DIR_ . 'fpay/src/logs/log-' . $date . '.txt';
            $handle = fopen($url, "r");
            if ($handle) {
                while (($line = fgets($handle)) !== false) {
                    // process the line read.
                    if (trim($line)) {
                        $json = json_decode($line);
                        if (json_last_error() === JSON_ERROR_NONE) {
                            $data[] = ['type' => 'json', 'value' => json_encode($json)];
                        } else {
                            $data[] = ['type' => 'text', 'value' => $line];
                        }
                    }
                }
                fclose($handle);
            }
        } catch (\Throwable $th) {
            $data = [];
        }

        return $data;
    }
}
