<?php
require_once _PS_MODULE_DIR_ . 'fpay/vendor/autoload.php';

use GuzzleHttp\Client;
use PrestaShop\Module\Fpay\Classes\FpayGatewayPayment;
use PrestaShop\Module\Fpay\Classes\FpayHttp;
use PrestaShop\Module\Fpay\Constants\FpayErrors;
use PrestaShop\Module\Fpay\Constants\FpayStates;

class FpayPaymentModuleFrontController extends ModuleFrontController
{
    /**
     * Initializes common front page content: header, footer and side columns.
     * Process the result of the payment made with Fpay
     *
     * @return void
     */
    public function initContent()
    {
        parent::initContent();

        //Get config fpay
        $config = Configuration::getMultiple(array('FPAY_PRIVATE_KEY', 'FPAY_PUBLIC_KEY'));
        if (!empty($config['FPAY_PUBLIC_KEY'])) {
            $this->publicKey = $config['FPAY_PUBLIC_KEY'];
        }
        if (!empty($config['FPAY_PRIVATE_KEY'])) {
            $this->privateKey = $config['FPAY_PRIVATE_KEY'];
        }
        $fpayGatewayPayment = new FpayGatewayPayment(
            new FpayHttp(new Client(),$this->publicKey,$this->privateKey)
        );        

        $fpayGatewayPayment->addLog('', false, 'paymentController', 'Se ha iniciado el proceso para validar el pago resultante en Fpay.');

        $order = new Order((int)(Tools::getValue('id')));
        $state = new OrderState((int)($order->getCurrentState()));
        $products = $order->getProducts();
        $payment = $order->getOrderPaymentCollection();

        $items = $this->setPaymentItems($products);    
        $formatOrder = $this->fpayFormatOrder($order, $state);
        $fpayIntention = null;
        if (Tools::getValue('status') == "success") {
            $fpayIntention = $fpayGatewayPayment->getIntention($payment[0]->transaction_id);
            $status = $fpayGatewayPayment->setOrderStatus($fpayIntention->state,$order,new OrderHistory());            
            $fpayGatewayPayment->addLog('', false, 'paymentController', 'El proceso de pago ha sido exitoso.');
        } else {
            $status = $fpayGatewayPayment->setOrderStatus(FpayStates::CANCELED,$order,new OrderHistory());
            $fpayGatewayPayment->addLog('', false, 'paymentController', 'El proceso de pago no se completó con éxito.');
        }
        
        $this->createMessage($fpayIntention, $order);

        $this->context->smarty->assign(array(
            'status' => $status,
            'order' => $formatOrder,
            'payment' => "",
            'products' => $items,
            'url' => $fpayGatewayPayment->getSiteUrl(),
            'module_dir' => _MODULE_DIR_.$this->module->name
        ));        
        $this->setTemplate('module:fpay/views/templates/payment_execution.tpl');
    }
    
    /**
     * Set the payment product items
     *
     * @param array $products
     * @return array $items
     */
    private function setPaymentItems(array $products)
    {
        $items = [];
        foreach ($products as $product) {
            $image = Image::getCover($product['id_product']);
            $currentProduct = new Product($product['id_product'], false, Context::getContext()->language->id);
            $link = new Link();
            $items[] = [
                'name' => $product['product_name'],
                'qty' => $product['product_quantity'],
                'unit' => number_format($product["total_price_tax_incl"] / (int)$product['product_quantity'], 2, ",", "."),
                'total' => number_format($product['total_price_tax_incl'], 2, ",", "."),
                'image' => "http://" . $link->getImageLink($currentProduct->link_rewrite, $image['id_image'], 'home_default'),
            ];
        }
        return $items;
    }

    /**
     * Format order data for fpay
     *
     * @param Order $order
     * @param OrderState $state
     * @return array
     */
    private function fpayFormatOrder(Order $order, OrderState $state)
    {
        return [
            'id' => $order->id,
            'date' => date("d-m-Y H:i:s", strtotime($order->date_add)),
            'payment' => $order->payment,
            'reference' => $order->reference,
            'subtotal' => number_format($order->total_products_wt, 2, ",", ".") . " CLP",
            'shipping' => number_format($order->total_shipping_tax_excl, 2, ",", ".") . " CLP",
            'total_paid' => number_format($order->total_paid, 2, ",", ".") . " CLP",
            'status' => $state->name[1],
        ];
    }

    /**
     * Create order status message for customer
     *
     * @param mixed|null $fpayIntention
     * @param Order $order
     * @return void
     */
    private function createMessage($fpayIntention, Order $order)
    {

        $transactionDetails = FpayErrors::PAID.': Error al realizar el pago con Fpay.';
        if (isset($fpayIntention->transaction)) {
            
            $date = date('Y-m-d H:i:s', strtotime($fpayIntention->create_time));
            
            $transactionDetails = "
			Estado: {$fpayIntention->state} \n 
			Total: {$fpayIntention->transaction->amount->total} {$fpayIntention->transaction->amount->currency} \n
			Tipo de Pago: {$fpayIntention->payment_method} \n
			Nº de Cuotas: {$fpayIntention->transaction->amount->installments_number} \n
			Fecha: $date \n
			Transacción Nº: {$fpayIntention->_id} \n			
			Orden N°: {$fpayIntention->transaction->purchase_order} \n
            ";
        }

        $thread = CustomerThreadCore::getCustomerMessages($order->id_customer, null, $order->id);

        if (empty($thread)) {
            $customerThread = new CustomerThreadCore();
            $customerThread->id_order = $order->id;
            $customerThread->id_customer = $order->id_customer;
            $customerThread->id_lang = 1;
            $customerThread->token = "FPAY-{$order->id}";
            $customerThread->id_contact = 0;
            $customerThread->save();

            $threadId = $customerThread->id;
            $messageId = null;
        } else {
            $threadId = $thread[0]['id_customer_thread'];
            $messageId = $thread[0]['id_customer_message'];
        }

        $orderMessage = new CustomerMessage($messageId);
        $orderMessage->id_order = (int)Tools::getValue('id');
        $orderMessage->id_customer_thread = $threadId;
        $orderMessage->message = $transactionDetails;
        $orderMessage->private = true;
        $orderMessage->save();
    }
}
