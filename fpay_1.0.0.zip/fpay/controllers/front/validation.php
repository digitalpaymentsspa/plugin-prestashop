<?php

class FpayValidationModuleFrontController extends ModuleFrontController
{
    /**
     * This class should be use by your Instant Payment
     * Notification system to validate the order remotely
     */
    public function postProcess()
    {
        /*
         * If the module is not active anymore, no need to process anything.
         */
        if ($this->module->active === false){ die; }
        $cart = $this->context->cart;
        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active){
			Tools::redirect('index.php?controller=order&step=1');
        }        

        /*
         * Validate module authorization
         */                        
        if (!$this->isValidOrder()) {            
            $payment_status = Configuration::get('PS_OS_ERROR');
            $message = $this->module->l('An error occurred while processing payment');
        } else {        
            $payment_status = Configuration::get('PS_OS_FPAY');
            $message = null;
        }
        
        $customer = new Customer($cart->id_customer);
		if (!Validate::isLoadedObject($customer)){
			Tools::redirect('index.php?controller=order&step=1');
        }        
		
		$total = (float)$cart->getOrderTotal(true, Cart::BOTH);                        
        $mail_vars = [
            '{fpay_title}' => $this->module->displayName,
            '{fpay_description}' => $this->module->description,
        ];        
        $currency_id = (int) Context::getContext()->currency->id;

        $this->module->validateOrder($cart->id, $payment_status, $total, $this->module->displayName, $message, $mail_vars, $currency_id, false, $customer->secure_key);
        Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
    }

    protected function isValidOrder()
    {
        $authorized = false;
		foreach (Module::getPaymentModules() as $module){
			if ($module['name'] == $this->module->name)
			{
				$authorized = true;
				break;
			}
        }
        return $authorized;		
    }
}
