<?php

namespace PrestaShop\Module\Fpay\Contracts\Classes;

use Order;
use OrderHistory;

interface FpayHttpClass
{    

    /**
     * Get bearer token for auth Fpay Api
     *
     * @return string access_token
     */
    public function getAuthToken();    

    /**
     * Create payment intenCreate payment intention in Fpay
     *
     * @param array $data
     * @return mixed
     */
    public function createPaymentIntention(array $data);

    /**
     * Get data of an intent and its current status in Fpay
     *
     * @param string $intentionId
     * @return void
     */
    public function getIntention(string $intentionId);


    /**
     * Send POST request for Fpay 
     *
     * @param string $url
     * @param array $data
     * @param array $headers
     * @return \GuzzleHttp\Message\ResponseInterface $response
     */
    public function post(string $url, array $data = [], array $headers = []);    

    /**
     * Send GET request for Fpay 
     *
     * @param string $url
     * @param array $data
     * @param array $headers
     * @return \GuzzleHttp\Message\ResponseInterface $response
     */
    public function get(string $url, array $data = [], array $headers = []);    

    /**
     * Set order status according Fpay intention
     *
     * @param string $fpayState
     * @param Order $order
     * @param OrderHistory $history
     * @return string
     */
    public function setOrderStatus(string $fpayState,Order $order,OrderHistory $history);
}
