<?php

namespace PrestaShop\Module\Fpay\Traits;

use Configuration;
use Country;
use Db;
use Language;
use OrderState;
use Tab;

trait FpaySetup
{

    /**
     * Get php version
     *
     * @return string
     */
    public function getPhpVersion()
    {
        return phpversion();
    }

    /**
     * Php min version validate
     *
     * @return void
     */
    public function phpVersionValidate()
    {
        if ((float)substr($this->getPhpVersion(), 0, 3) < 7.1) {
            $this->_errors[] = $this->l('La versión de PHP ' . phpversion() . ' no es compatible con este módulo, por favor actualice a PHP 7.4.');
            return false;
        }
        return true;
    }

    /**
     * Check if has curl extension enable
     *
     * @return boolean
     */
    public function hasCurlExt()
    {
        return extension_loaded('curl');
    }

    public function installTab()
    {
        $tab = new Tab();
        $tab->class_name = 'FpayLogController';
        $tab->module = $this->name;
        $tab->id_parent = (int)Tab::getIdFromClassName('DEFAULT');
        $tab->icon = 'description';
        $languages = Language::getLanguages();
        foreach ($languages as $lang) {
            $tab->name[$lang['id_lang']] = $this->l('Fpay logs');
        }
        return $tab->save();
    }

    public function uninstallTab()
    {
        $exists = $this->db->getRow("SELECT * FROM `" . _DB_PREFIX_ . "tab` os WHERE module='".$this->name."';");
        if ($exists) {            
            $tab = new Tab($exists['id_tab']);
            return $tab->delete();
        }  
        return true; 
    }

    /**
     * Pre install validation
     *
     * @return bool
     */
    public function preInstallValidation()
    {
        $success = true;
        if ($this->phpVersionValidate()) {
            if ($this->hasCurlExt() === false) {
                $this->_errors[] = $this->l('Debe habilitar la extensión cURL en su servidor para instalar este módulo');
                $success = false;
            }

            $iso_code = Country::getIsoById(Configuration::get('PS_COUNTRY_DEFAULT'));

            if (in_array($iso_code, $this->limited_countries) === false) {
                $this->_errors[] = $this->l('Este módulo no está disponible en tu país');
                $success = false;
            }
        } else {
            $success = false;
        }
        return $success;
    }

    /**
     * parent install module
     *
     * @return bool
     */
    public function parentInstall()
    {
        return parent::install();
    }

    /**
     * Install module
     */
    public function install()
    {

        //PHP min versión validate
        if (!$this->preInstallValidation()) {
            return false;
        }

        Configuration::updateValue('FPAY_TEST_MODE', Configuration::get('FPAY_TEST_MODE', false));

        return $this->parentInstall() && $this->installTab() &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('paymentReturn') &&
            $this->registerHook('displayOrderDetail') &&
            $this->registerHook('actionOrderStatusPostUpdate') &&
            $this->registerHook('actionOrderReturn') &&
            $this->registerHook('displayBackOfficeHeader') &&
            $this->installFpayOrderState() && $this->installDB();
    }

    /**
     * Drop fpay custom database table
     *
     * @return bool
     */
    public function dropFpayTableIfExist()
    {
        return $this->db->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'fpay`;');
    }

    /**
     * Create fpay custom database table
     *
     * @return bool
     */
    public function createFpayTable()
    {
        return $this->db->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'fpay` (' .
            'id int(11) unsigned NOT NULL AUTO_INCREMENT,' .
            'intention_id varchar(255) NOT NULL,' .
            'order_id int(11) unsigned NOT NULL,' .
            'PRIMARY KEY (id),' .
            'UNIQUE `INTENTION_UNIQ` (intention_id),' .
            'UNIQUE `ORDER_UNIQ` (order_id)' .
            ') ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;');
    }

    /**
     * install fpay custom database table 
     *
     * @return bool
     */
    public function installDB()
    {
        // Run sql for creating DB tables        
        $dropTable = $this->dropFpayTableIfExist();
        if (!$dropTable) {
            $this->_errors[] = $this->l('Error de base de datos: ' . $this->db->getMsgError());
            return false;
        }

        $createTable = $this->createFpayTable();

        if (!$createTable) {
            $this->_errors[] = $this->l('Error de base de datos: ' . $this->db->getMsgError());
            return false;
        }

        return $dropTable && $createTable;
    }

    /**
     * Check if fpay order state is installed
     *
     * @return boolean|int
     */
    public function hasFpayOrderState()
    {
        return Configuration::get('PS_OS_FPAY');
    }

    /**
     * install fpay custom order state 
     *
     * @return bool
     */
    public function installFpayOrderState()
    {
        $success = true;
        if (!$this->hasFpayOrderState()) {
            $orderState = new OrderState();
            $orderState->send_email = false;
            $orderState->module_name = $this->name;
            $orderState->invoice = false;
            $orderState->color = '#98c3ff';
            $orderState->logable = true;
            $orderState->shipped = false;
            $orderState->unremovable = false;
            $orderState->delivery = false;
            $orderState->hidden = false;
            $orderState->paid = false;
            $orderState->deleted = false;
            $orderState->name = array((int)Configuration::get('PS_LANG_DEFAULT') => pSQL($this->l('Fpay - Esperando confirmación')));
            $success = $this->addOrderState($orderState);
            if ($success) {
                // We save the order State ID in PS_OS_FPAY database
                Configuration::updateValue('PS_OS_FPAY', $orderState->id);
                // We copy the module logo in order state logo directory
                copy(_PS_MODULE_DIR_ .'fpay/logo.png', _PS_MODULE_DIR_ . 'fpay/../../img/os/' . $orderState->id . '.gif');
                copy(_PS_MODULE_DIR_ . 'fpay/logo.png', _PS_MODULE_DIR_ . 'fpay/../../img/tmp/order_state_mini_' . $orderState->id . '.gif');
            }
        }
        return $success;
    }

    /**
     * add custom fpay order state to prestashop
     *
     * @param OrderState $orderState
     * @return boolean
     */
    public function addOrderState(OrderState $orderState)
    {
        $exists = $this->db->getRow("SELECT * FROM `" . _DB_PREFIX_ . "order_state` os WHERE module_name='$this->name';");
        return (bool)($exists ? ($orderState->id = $exists["id_order_state"]) : $orderState->add());
    }

    /**
     * Uninstall plugin 
     *
     * @return bool
     */
    public function uninstall()
    {
        if (
            !Configuration::deleteByName('FPAY_TEST_MODE') ||
            !Configuration::deleteByName('FPAY_PUBLIC_KEY') ||
            !Configuration::deleteByName('FPAY_PRIVATE_KEY') ||
            !parent::uninstall()||
            !$this->uninstallTab()
        ) {
            return false;
        }

        return true;
    }

}
