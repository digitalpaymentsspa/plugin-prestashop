<?php 

declare(strict_types=1);

namespace PrestaShop\Module\Fpay\Traits\Tests;

use Address;
use Cart;
use Configuration;
use Context;
use Order;
use PrestaShop\Module\Fpay\Classes\FpayCore;

trait FpayHooksTest{   
     
    public function testHookActionOrderReturn()
    {
        $cart = $this->getFakeCart();
        $fakeParams=[
            'cart' => $cart
        ];
        $this->assertIsBool($this->fpay->hookActionOrderReturn($fakeParams));
        $this->fpay->unitTest = true;
        $this->assertIsBool($this->fpay->checkCurrency($cart));
    }    

    public function testHookDisplayOrderDetail()
    {
        $context = Context::getContext();
        $fakeParams=[
            'cart' => $this->getFakeCart()
        ];
        $this->fpay->hookDisplayOrderDetail($fakeParams);
        $this->fpay->unitTest = true;
        $context->cookie->fpayError = 'FakeError';
        $this->assertIsString($this->fpay->hookDisplayOrderDetail($fakeParams));
    }

    public function testHookDisplayBackOfficeHeader()
    {
        $this->fpay->unitTest = true;
        $_SERVER['REQUEST_URI'] = 'modules/fpay/logs';
        $this->assertTrue($this->fpay->hookDisplayBackOfficeHeader());
    }

    public function testHookPaymentOptions()
    {
        $fakeParams=[
            'cart' => $this->getFakeCart()
        ];

        $this->assertIsBool($this->fpay->hookPaymentOptions($fakeParams));
        $this->fpay->unitTest = true;
        $this->assertIsArray($this->fpay->hookPaymentOptions($fakeParams));
    }

    public function testHookPaymentReturn()
    {
        $fakeParams =[            
            'cart' => $this->getFakeCart(),
            'order' => new Order($_ENV['TEST_ORDER_ID'])
        ];    

        $this->fpay->active = false;
        $this->assertIsBool($this->fpay->hookPaymentReturn($fakeParams));
        $this->fpay->active = true;
        $mock = $this->getMockBuilder(FpayCore::class)
            ->onlyMethods(['validateState'])
            ->getMock();

        $mock->expects($this->any())
            ->method('validateState')
            ->will($this->returnValue(true));  

        $mock->unitTest = true;

        $this->assertIsString($mock->hookPaymentReturn($fakeParams));
    }

    public function testHookPaymentReturnValidateStateFailed()
    {
        $fakeParams =[            
            'cart' => $this->getFakeCart(),
            'order' => new Order($_ENV['TEST_ORDER_ID'])
        ];
        
        $mock = $this->getMockBuilder(FpayCore::class)
            ->onlyMethods(['validateState'])
            ->getMock();

        $mock->expects($this->any())
            ->method('validateState')
            ->will($this->returnValue(false));  

        $this->assertIsString($mock->hookPaymentReturn($fakeParams));
    }
    
    public function testHookPaymentReturnNoUrl()
    {
        $fakeParams =[            
            'cart' => $this->getFakeCart(),
            'order' => new Order($_ENV['TEST_ORDER_ID'])
        ];    
        
        $mock = $this->getMockBuilder(FpayCore::class)
            ->onlyMethods(['validateState','createIntention'])
            ->getMock();

        $mock->expects($this->any())
            ->method('validateState')
            ->will($this->returnValue(true));  
        
            $mock->expects($this->any())
            ->method('createIntention')
            ->will($this->returnValue('')); 
            
        $mock->unitTest = true;

        $this->assertIsString($mock->hookPaymentReturn($fakeParams));
    }

    public function testValidateState()
    {
        $this->assertIsBool($this->fpay->ValidateState(Configuration::get('PS_OS_FPAY')));
    }

    protected function getFakeCart()
    {
        $context = Context::getContext();
        $cart = new Cart();
        $cart->id_customer = (int)($context->cookie->id_customer);
        $cart->id_address_delivery = (int)  (Address::getFirstCustomerAddressId($cart->id_customer));
        $cart->id_address_invoice = $cart->id_address_delivery;
        $cart->id_lang = (int)($context->cookie->id_lang);
        $cart->id_currency = (int)($context->cookie->id_currency);
        $cart->id_carrier = 1;
        $cart->recyclable = 0;
        $cart->gift = 0;
        $cart->add();
        $context->cookie->id_cart = (int)($cart->id);    
        $cart->update();
        return $cart;
    }
}