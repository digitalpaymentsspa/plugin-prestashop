<?php

namespace PrestaShop\Module\Fpay\Classes;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Configuration;
use Db;
use HelperForm;
use PaymentModule;
use Tools;
use GuzzleHttp\Client;
use Language;
use PrestaShop\Module\Fpay\Classes\FpayGatewayPayment;
use PrestaShop\Module\Fpay\Classes\FpayHttp;
use PrestaShop\Module\Fpay\Traits\FpaySetup;
use PrestaShop\Module\Fpay\Traits\FpayHooks;

/**
 * Fpay module base class
 */
class FpayCore extends PaymentModule{
    use FpaySetup, FpayHooks;

    /**
     * Define unitTest mode for uninstall method
     *
     * @var boolean
     */
    public $unitTest = false;
    
    /**
     * Store errors after sending data
     *
     * @var array
     */
    protected $postErrors = [];

    /**
     * Database instance
     *
     * @var Db
     */
    private $db;
    
    /**
     * FPay Merchant Public Key
     *
     * @var string|null
     */
    private $publicKey = null;

    /**
     * FPay Merchant Private Key
     *
     * @var string|null
     */
    private $privateKey = null;
    /**
     * Fpay Gateway payment
     *
     * @var FpayGatewayPayment
     */
    private $fpayGatewayPayment;

    public function __construct()
    {        
        //Fpay gateway config vars
        $config = Configuration::getMultiple(array('FPAY_PRIVATE_KEY', 'FPAY_PUBLIC_KEY'));
        if (!empty($config['FPAY_PUBLIC_KEY'])) {
            $this->publicKey = $config['FPAY_PUBLIC_KEY'];
        }
        if (!empty($config['FPAY_PRIVATE_KEY'])) {
            $this->privateKey = $config['FPAY_PRIVATE_KEY'];
        }
        $this->fpayGatewayPayment = new FpayGatewayPayment(
            new FpayHttp(new Client(),$this->publicKey,$this->privateKey)
        );
        //Prestashop plugins config vars
        $this->name = 'fpay';
        $this->tab = 'payments_gateways';
        $this->version = $this->fpayGatewayPayment->version;
        $this->author = 'Fpay';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.7.0', 'max' => _PS_VERSION_);

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;
        
        parent::__construct();

        $this->displayName = $this->l('Fpay');
        $this->description = $this->l('Plugin oficial de Fpay versión ' . $this->version);

        $this->confirmUninstall = $this->l('Está seguro que desea desinstalar Fpay?');

        $this->limited_countries = array('CL');

        $this->limited_currencies = array('CLP');

        $this->db = Db::getInstance();
    }    


    /**
     * Validate required fields
     *
     * @return void
     */
    protected function postValidation()
    {
        if (!Tools::getValue('FPAY_PUBLIC_KEY') || !Tools::getValue('FPAY_PRIVATE_KEY')) {
            $this->postErrors[] = $this->trans('Debe completar todos los campos.');
        }
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        $html = '';
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitFpayModule')) === true) {
            $this->postValidation();
            if (count($this->postErrors)) {
                $html .= $this->displayError($this->postErrors[0]);
            } else {
                $this->postProcess();
                $html .= $this->displayConfirmation('Datos del comercio actualizados con éxito.');
            }
        } else {
            $html .= '<br>';
        }

        $this->context->smarty->assign('module_dir', $this->_path);
        $html .= $this->renderForm();
        //Remove configuration hooks button and add logs button                
        $logsUrl = $this->context->link->getAdminLink('AdminFpayLog', true);

        $html .= "<script>$('#desc-module-hook').remove();\n";
        $html .= "var ulToolbar = $('#desc-module-back').parent().parent();\n";
        $html .= "ulToolbar.prepend(`<li>";
        $html .= "<a class='toolbar_btn' href='$logsUrl'><i class='process-icon- icon-file-text'/><div>Logs</div></a>";
        $html .= "</li>`)</script>";
        return $html;
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitFpayModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $this->unitTest ? 'success' : $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Get languages prestashop
     *
     * @return array
     */
    public function getLanguages()
    {
        $cookie = $this->context->cookie;
        $this->allow_employee_form_lang = (int) Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG');
        if ($this->allow_employee_form_lang && !$cookie->employee_form_lang) {
            $cookie->employee_form_lang = (int) Configuration::get('PS_LANG_DEFAULT');
        }

        $lang_exists = false;
        $this->_languages = Language::getLanguages(false);
        foreach ($this->_languages as $lang) {
            if (isset($cookie->employee_form_lang) && $cookie->employee_form_lang == $lang['id_lang']) {
                $lang_exists = true;
            }
        }

        $this->default_form_language = $lang_exists ? (int) $cookie->employee_form_lang : (int) Configuration::get('PS_LANG_DEFAULT');

        foreach ($this->_languages as $k => $language) {
            $this->_languages[$k]['is_default'] = (int) ($language['id_lang'] == $this->default_form_language);
        }

        return $this->_languages;
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                    'title' => 'Ingresa o crea tu cuenta en <a href="https://fpay.cl/comercios/cuenta/login" target="_blank">Portal Comercios Fpay </a> para obtener tus credenciales.',
                    'icon' => 'icon-cogs'
                ),
                'input' => array(
                    array(
                        'col' => 6,
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-key"></i>',
                        'desc' => $this->l('Ingrese la llave pública de su comercio'),
                        'name' => 'FPAY_PUBLIC_KEY',
                        'label' => $this->l('Llave pública'),
                    ),
                    array(
                        'col' => 6,
                        'type' => 'text',
                        'name' => 'FPAY_PRIVATE_KEY',
                        'prefix' => '<i class="icon icon-key"></i>',
                        'desc' => $this->l('Ingrese la llave privada de su comercio'),
                        'label' => $this->l('Llave privada'),
                    ),                    
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                )
            )
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'FPAY_TEST_MODE' => Configuration::get('FPAY_TEST_MODE', false),
            'FPAY_PUBLIC_KEY' => Configuration::get('FPAY_PUBLIC_KEY', null),
            'FPAY_PRIVATE_KEY' => Configuration::get('FPAY_PRIVATE_KEY', null),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }  
}