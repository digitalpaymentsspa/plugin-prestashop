<?php

namespace PrestaShop\Module\Fpay\Constants;

/**
 * This class contains the fpay states
 */
class FpayErrors{
    const CREDENTIALS = 'FpayPrestashopError-001'; //Problemas de credenciales, error de ambiente al que apunta el módulo.
    const CREATE_INTENTION = 'FpayPrestashopError-002'; //Error al intentar crear la intención de pago.
    const GET_INTENTION = 'FpayPrestashopError-003'; //Error al intentar obtener la intención de pago en Fpay
    const PAID = 'FpayPrestashopError-004'; //Error al realizar el pago con Fpay.
    const REFUND = 'FpayPrestashopError-005'; //Error al generar un reembolso en Fpay.    
}