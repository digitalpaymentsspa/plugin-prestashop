# Fpay
Módulo oficial para el CMS [**PrestaShop**](https://www.prestashop.com/).
- Contributors: Falabella.cl
- Tags: Fpay, PrestaShop, payments, payment, Falabella
- Requires at least: 1.7.0.0
- Tested up to: 1.7.0.6
- Stable tag: 0.9
- Requires PHP: 7.1 - 7.2
- License: GPLv2 or later
- License URI: 
 [![N|Solid](https://www.gnu.org/graphics/gplv3-88x31.png)](https://www.gnu.org/licenses/gpl-2.0.html)

#### Changelog
A continuación puede observar el registro de los cambios tras cada actualización.
| Versión | Cambios |
| ------ | ------ |
| **1.0.0** | ▪ Fpay versión lite.  |
## License
GPL