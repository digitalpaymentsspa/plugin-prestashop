<?php

declare(strict_types=1);

namespace Tests\Unit\Classes;

use Configuration;
use PrestaShop\Module\Fpay\Classes\FpayCore;
use PrestaShop\Module\Fpay\Traits\Tests\FpayHooksTest;
use PrestaShop\Module\Fpay\Traits\Tests\FpaySetupTest;
use Tests\BaseTest;
use Tools;

class FpayCoreTest extends BaseTest
{
    use FpaySetupTest, FpayHooksTest;

    protected FpayCore $fpay;

    protected function setUp(): void
    {
        $this->fpay = new FpayCore();
    }

    /**
     * Check if class file exists
     *                                                                                                                                                                                                                  
     * @return void
     */
    public function testFileExists()
    {
        $filePath = _PS_MODULE_DIR_ . 'fpay/fpay.php';
        $exists = file_exists($filePath);
        $this->assertTrue($exists);
    }

    public function testClassConstructor()
    {
        $this->assertInstanceOf(FpayCore::class, $this->fpay);
    }

    public function testGetContentNoSubmitFpayModule()
    {
        $this->fpay->unitTest = true;
        $this->assertIsString($this->fpay->getContent());
    }

    public function testGetContentSubmitFpayModule()
    {
        $_POST['submitFpayModule']= 'submit';        
        $this->fpay->unitTest = true;
        $this->assertIsString($this->fpay->getContent());
    }

    public function testGetContentSubmitPostValidation()
    {
        $_POST['submitFpayModule']= 'submit';        
        $_POST['FPAY_PUBLIC_KEY']= Configuration::get('FPAY_PUBLIC_KEY', null);        
        $_POST['FPAY_PRIVATE_KEY']= Configuration::get('FPAY_PRIVATE_KEY', null);        
        $this->fpay->unitTest = true;
        $this->assertIsString($this->fpay->getContent());
    }
}
