<?php

declare(strict_types=1);

namespace Tests\Unit\Classes;

use Address;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\ServerException;
use GuzzleHttp\Message\Request;
use Order;
use OrderHistory;
use OrderPayment;
use PHPUnit\Framework\MockObject\MockObject;
use PrestaShop\Module\Fpay\Classes\FpayGatewayPayment;
use PrestaShop\Module\Fpay\Classes\FpayHttp;
use PrestaShop\Module\Fpay\Constants\FpayStates;
use PrestaShopCollection;
use Tests\BaseTest;

class FpayGatewayPaymentTest extends BaseTest
{

    protected FpayGatewayPayment $fpayGatewayPayment;
    /**
     * @var FpayHttp&MockObject
     */
    protected $mockFpayHttp;
    /**
     * @var FpayGatewayPayment&MockObject
     */
    protected $mockFpayGatewayPayment;
    /**
     * @var Order&MockObject
     */
    protected $mockOrder;
    /**
     * @var Address&MockObject
     */
    protected $mockAddress;
    
    protected $testIntentionData;

    protected function setUp(): void
    {        
        $this->mockFpayHttp = $this->createMock(FpayHttp::class);
        $this->mockFpayHttp->expects($this->any())->method('getVersion')->willReturn('2.0.1');
        $this->mockFpayHttp->expects($this->any())->method('getCountryCode')->willReturn('cl');

        $this->mockFpayGatewayPayment = $this->createMock(FpayGatewayPayment::class);

        $this->mockOrder = $this->createMock(Order::class);
        $this->mockOrder->id = 1;
        $this->mockOrder->total_paid = 50;
        $this->mockOrder->total_products = 50;
        $this->mockOrder->total_paid_tax_incl = 50;
        $this->mockOrder->total_paid_tax_excl = 50;
        $this->mockOrder->total_shipping = 0;

        $this->mockAddress = $this->createMock(Address::class);
        $this->mockAddress->address1 = 'Cra 78';
        $this->mockAddress->address2 = '# 21a-10 ';
        $this->mockAddress->city = 'Santiago';
        $this->mockAddress->phone = '3123456789';
        $this->mockAddress->firstname = 'Nombre';
        $this->mockAddress->lastname = 'De Prueba';

        $this->fpayGatewayPayment = new FpayGatewayPayment($this->mockFpayHttp);
        $this->testIntentionData = json_decode(file_get_contents(self::FPAY_TEST_DIR . 'Classes/DataTest/IntentionData.json'));
    }

    /**
     * Check if class file exists
     *                                                                                                                                                                                                                  
     * @return void
     */
    public function testFileExists()
    {
        $filePath = _PS_MODULE_DIR_ . 'fpay/src/Classes/FpayGatewayPayment.php';
        $exists = file_exists($filePath);
        $this->assertTrue($exists);
    }


    public function testClassConstructor(): void
    {
        $this->assertIsString($this->fpayGatewayPayment->version);
    }

    public function getIntentionProvider(): array
    {
        return [
            ['string_fpay_intention_id']
        ];
    }

    /**
     * @expectedException ServerException
     * @dataProvider getIntentionProvider
     */
    public function testGetIntentionServerException(string $intentionId): void
    {
        $this->mockFpayHttp
            ->expects($this->any())
            ->method('getIntention')
            ->with($intentionId)
            ->willThrowException(
                new ServerException(
                    'Error al comunicarse con el servidor',
                    new Request('GET', '/getIntention')
                )
            );
        $this->expectException(ServerException::class);

        $this->fpayGatewayPayment->getIntention($intentionId);
    }

    /**
     * @expectedException ClientException
     * @dataProvider getIntentionProvider
     */
    public function testGetIntentionClientException(string $intentionId): void
    {
        $this->mockFpayHttp
            ->expects($this->any())
            ->method('getIntention')
            ->with($intentionId)
            ->willThrowException(
                new ClientException(
                    'Error al intentar obtener la intención de pago en Fpay',
                    new Request('GET', '/getIntention')
                )
            );

        $this->expectException(ClientException::class);
        $this->fpayGatewayPayment->getIntention($intentionId);
    }

    /**
     * @dataProvider getIntentionProvider
     */
    public function testGetIntention(string $intentionId)
    {
        $this->mockFpayHttp
            ->expects($this->any())
            ->method('getIntention')
            ->with($intentionId)
            ->willReturn($this->testIntentionData);

        $intention = $this->fpayGatewayPayment->getIntention($intentionId);

        $this->assertIsObject($intention);
        $this->assertSame($this->testIntentionData, $intention);
    }

    public function getSiteUrlProvider(): array
    {
        return [
            [true], //WithoutPrestashop
            [false], //WithPrestashop
        ];
    }

    /**
     * @dataProvider getSiteUrlProvider
     *
     */
    public function testGetSiteUrl($WithoutPrestashop): void
    {
        $expectValue = $this->fpayGatewayPayment->getSiteUrl($WithoutPrestashop);
        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('getSiteUrl')
            ->with($WithoutPrestashop)
            ->willReturn($expectValue);

        $siteUrl = $this->mockFpayGatewayPayment->getSiteUrl($WithoutPrestashop);

        $this->assertIsString($siteUrl);
        $this->assertSame($expectValue, $siteUrl);
    }

    public function processPaymentProvider(): array
    {
        return [
            [$this->mockOrder]
        ];
    }

    public function testProcessPayment()
    {
        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('addLog')
            ->with('', true, 'processPayment', 'Se ha iniciado un proceso de pago con Fpay.');

        $this->mockOrder
            ->expects($this->any())
            ->method('hasPayments')
            ->willReturn(false);

        $orderProducts = [
            [
                'product_id' => 1,
                'product_name' => 'test_product_name',
                'product_quantity' => 1,
                'price' => 20,
                'total_price_tax_incl' => 20,
                'total_shipping_price_tax_excl' => 0,
                'id_category_default' => 1
            ]
        ];

        $this->mockOrder
            ->expects($this->any())
            ->method('getProducts')
            ->willReturn($orderProducts);

        $items = $this->fpayGatewayPayment->setItems($orderProducts);

        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('setItems')
            ->with($orderProducts)
            ->willReturn($items);

        $intentionData = $this->fpayGatewayPayment->setIntentionData($this->mockOrder, $this->mockAddress, $items);

        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('setIntentionData')
            ->with($this->mockOrder, $this->mockAddress, $items)
            ->willReturn($intentionData);

        $this->mockFpayHttp->orderId = $this->mockOrder->id;

        $this->mockFpayHttp
            ->expects($this->any())
            ->method('createPaymentIntention')
            ->willReturn($this->testIntentionData);

        $mockOrderPayment = $this->createMock(OrderPayment::class);
        $prestashopCollection = new PrestaShopCollection(OrderPayment::class);
        $prestashopCollection[0] = $mockOrderPayment;
        $this->mockOrder
            ->expects($this->any())
            ->method('getOrderPaymentCollection')
            ->willReturn($prestashopCollection);

        $expectValue = $this->fpayGatewayPayment->processPayment($this->mockOrder, $this->mockAddress);
        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('processPayment')
            ->with($this->mockOrder, $this->mockAddress)
            ->willReturn($expectValue);

        $paymentUrl = $this->mockFpayGatewayPayment->processPayment($this->mockOrder, $this->mockAddress);

        $this->assertIsString($paymentUrl);
        $this->assertSame($expectValue, $paymentUrl);
    }

    function testGetRefundAmountIfTheIntentionDoesNotHave()
    {

        $expectValue = $this->fpayGatewayPayment->getRefundAmount($this->testIntentionData);
        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('getRefundAmount')
            ->with($this->testIntentionData)
            ->willReturn(0);

        $refundAmount = $this->mockFpayGatewayPayment->getRefundAmount($this->testIntentionData);
        $this->assertIsNumeric($refundAmount);
        $this->assertSame($expectValue, $refundAmount);
    }

    function testGetRefundAmountIfTheIntentionHave()
    {
        $this->testIntentionData->gateway->resume->refunds = json_decode(json_encode([[
            'state' => 'applied',
            'refunded_amount' => 2.0
        ]]));
        $expectValue = $this->fpayGatewayPayment->getRefundAmount($this->testIntentionData);
        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('getRefundAmount')
            ->with($this->testIntentionData)
            ->willReturn($expectValue);

        $refundAmount = $this->mockFpayGatewayPayment->getRefundAmount($this->testIntentionData);
        $this->assertIsNumeric($refundAmount);
        $this->assertSame($expectValue, $refundAmount);
    }

    function testRefundIntention()
    {
        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('addLog')
            ->with('', true, 'refundIntention', 'Se ha iniciado un proceso de reembolso desde prestashop.');

        $mockOrderHistory = $this->createMock(OrderHistory::class);
        $mockOrderPayment = $this->createMock(OrderPayment::class);
        $prestashopCollection = new PrestaShopCollection(OrderPayment::class);
        $prestashopCollection[0] = $mockOrderPayment;
        $mockOrderPayment->transaction_id = $this->testIntentionData->_id;
        $this->mockOrder
            ->expects($this->any())
            ->method('getOrderPaymentCollection')
            ->willReturn($prestashopCollection);

        $this->mockFpayHttp
            ->expects($this->any())
            ->method('getIntention')
            ->with($mockOrderPayment->transaction_id)
            ->willReturn($this->testIntentionData);

        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('getRefundAmount')
            ->with($this->testIntentionData)
            ->willReturn(0);

        $merchantUniqueId = 'ps_' . $this->mockOrder->id . '_' . date('Ymdhisu');

        $this->testIntentionData->state = FpayStates::PARTIALLY_REFUNDED;
        $this->mockFpayHttp
            ->expects($this->any())
            ->method('refundIntention')

            ->willReturn($this->testIntentionData);

        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('setOrderStatus')
            ->with(FpayStates::PARTIALLY_REFUNDED, $this->mockOrder, $mockOrderHistory)
            ->willReturn('refunded');

        $this->fpayGatewayPayment->refundIntention($this->mockOrder, 1);
        $this->assertTrue(true);
    }


    public function testProcessPending()
    {
        $this->mockFpayGatewayPayment
            ->expects($this->any())
            ->method('processPending')
            ->willReturn(true);

        $proccessResult = $this->mockFpayGatewayPayment->processPending();
        $this->assertTrue($proccessResult);
        $this->assertSame($proccessResult, $this->fpayGatewayPayment->processPending());
    }
}
