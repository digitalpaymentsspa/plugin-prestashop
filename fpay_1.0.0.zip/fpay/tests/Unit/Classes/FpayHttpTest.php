<?php

declare(strict_types=1);

namespace Tests\Unit\Classes;

use Address;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Message\Request;
use GuzzleHttp\Message\Response;
use GuzzleHttp\Stream\Stream;
use Order;
use OrderHistory;
use PrestaShop\Module\Fpay\Classes\FpayGatewayPayment;
use PrestaShop\Module\Fpay\Classes\FpayHttp;
use PrestaShop\Module\Fpay\Constants\FpayStates;
use PHPUnit\Framework\MockObject\MockObject;
use PrestaShop\Module\Fpay\Constants\FpayErrors;
use Tests\BaseTest;

class FpayHttpTest extends BaseTest
{
    /**
     * @var Client&MockObject
     */
    protected $mockClient;

    /**
     * @var FpayHttp&MockObject
     */
    protected $mockFpayHttp;

    /**
     * @var OrderHistory&MockObject
     */
    protected $mockOrderHistory;

    /**
     * @var Order&MockObject
     */
    protected $mockOrder;

    protected $testIntentionData;

    protected $authSign = 'public_key' . ":" . 'private_key';
    protected $country = 'cl';

    protected function setUp(): void
    {
        $this->mockClient = $this->createMock(Client::class);
        $this->mockFpayHttp = $this->createMock(FpayHttp::class);
        $this->mockFpayHttp->unitTest = true;        
        
        $this->fpayHttp = new FpayHttp($this->mockClient, 'public_key', 'private_key');
        $this->fpayHttp->unitTest = true;        

        $this->mockOrder = $this->createMock(Order::class);
        $this->mockOrder->id = 1;
        $this->mockOrder->total_paid = 50;
        $this->mockOrder->total_products = 50;
        $this->mockOrder->total_paid_tax_incl = 50;
        $this->mockOrder->total_paid_tax_excl = 50;
        $this->mockOrder->total_shipping = 0;

        $this->fpayHttp->orderId = $this->mockOrder->id;
        $this->mockFpayHttp->orderId = $this->mockOrder->id;

        $this->mockOrderHistory = $this->createMock(OrderHistory::class);

        $this->testIntentionData = json_decode(file_get_contents(self::FPAY_TEST_DIR . 'Classes/DataTest/IntentionData.json'));
    }

    /**
     * Check if class file exists
     *                                                                                                                                                                                                                  
     * @return void
     */
    public function testFileExists()
    {
        $filePath = _PS_MODULE_DIR_ . 'fpay/src/Classes/FpayHttp.php';
        $exists = file_exists($filePath);
        $this->assertTrue($exists);
    }

    public function testClassConstructor()
    {              
        $this->assertInstanceOf(FpayHttp::class, $this->fpayHttp);
    }

    public function getAuthTokenProvider(): array
    {        
        return [
            [
                "/sso/oauth2/v2/token", [
                    "grant_type" => "client_credentials"
                ], [
                    "Content-Type" => "application/json",
                    "Authorization" => "Basic {$this->authSign}",
                    "fp-flow-country" => $this->country
                ]
            ]
        ];
    }

    /**
     * @dataProvider getAuthTokenProvider
     *
     * @return void
     */
    public function testGetAuthTokenException(string $url, array $data = [], array $headers = [])
    {
        $this->mockFpayHttp
            ->expects($this->any())
            ->method('addLog')
            ->with('', false, 'getAuthToken', 'Se intentó realizar la autenticación en Fpay sin éxito.');

        $this->mockFpayHttp
            ->expects($this->any())
            ->method('setOrderStatus')
            ->with(FpayStates::VOIDED, $this->mockOrder, $this->mockOrderHistory);

        $this->mockClient
            ->expects($this->any())
            ->method('post')
            ->with($this->fpayHttp->getApiUrl() . $url, [
                'body' => json_encode($data),
                'headers' => $headers
            ])
            ->willThrowException(
                new ClientException(
                    'Se intentó realizar la autenticación en Fpay sin éxito.',
                    new Request('POST', $url)
                )
            );      

        $this->expectException(ClientException::class);
        $this->fpayHttp->getAuthToken();        
    }

    /**
     * @dataProvider getAuthTokenProvider
     *
     * @return void
     */
    public function testGetAuthToken(string $url, array $data = [], array $headers = [])
    {                
        $response = Stream::factory(json_encode([
            "access_token"=>"token"
        ]));

        $this->mockClient
            ->expects($this->any())
            ->method('post')
            ->with($this->fpayHttp->getApiUrl() . $url, [
                'body' => json_encode($data),
                'headers' => $headers
            ])
            ->willReturn(new Response(200,[],
                $response
            ));      

        $token = $this->fpayHttp->getAuthToken();        

        $this->mockFpayHttp
            ->expects($this->any())
            ->method('getAuthToken')
            ->willReturn($token);

        $this->assertIsString($token);
        $this->assertSame($this->mockFpayHttp->getAuthToken(),$token);
    }

    public function createPaymentIntentionProvider():array
    {
        return [
            [
                "/checkout/payments", [
                    'intention-data'
                ], [
                    "Content-Type" => "application/json",
                    "Authorization" => "Basic {$this->authSign}",
                    "fp-flow-country" => $this->country
                ]
            ]
        ];
    }

    /**
     * @dataProvider createPaymentIntentionProvider
     *
     * @return void
     */
    public function testCreatePaymentIntentionException(string $url, array $data = [], array $headers = [])
    {
        $partialMockFpayHttp = $this->getMockBuilder(FpayHttp::class)
            ->setConstructorArgs([$this->mockClient, 'public_key', 'private_key'])
            ->onlyMethods(['addLog', 'getAuthToken', 'post', 'setOrderStatus'])
            ->getMock();
            
        $partialMockFpayHttp->orderId = $this->mockOrder->id;
        $partialMockFpayHttp->unitTest = true;

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('addLog');                            
        
        $partialMockFpayHttp
            ->expects($this->any())
            ->method('getAuthToken')
            ->willReturn('token');

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('setOrderStatus');            

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('post')
            ->willThrowException(
                new ClientException(
                    'Error en los datos',
                    new Request('GET', $url)
                )
            );      

        $this->expectException(ClientException::class);
        $partialMockFpayHttp->createPaymentIntention($data);
    }

    /**
     * @dataProvider createPaymentIntentionProvider
     *
     * @return void
     */
    public function testCreatePaymentIntention(string $url, array $data = [], array $headers = [])
    {
        $partialMockFpayHttp = $this->getMockBuilder(FpayHttp::class)
            ->setConstructorArgs([$this->mockClient, 'public_key', 'private_key'])
            ->onlyMethods(['addLog', 'getAuthToken', 'post'])
            ->getMock();
        $partialMockFpayHttp->orderId = $this->mockOrder->id;

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('addLog');            

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('getAuthToken')
            ->willReturn('token');

        $response = Stream::factory(json_encode($this->testIntentionData));

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('post')         
            ->willReturn(new Response(200,[],
                $response
            ));      

        $intention = $partialMockFpayHttp->createPaymentIntention($data);        

        $this->mockFpayHttp
            ->expects($this->any())
            ->method('createPaymentIntention')
            ->willReturn($intention);

        $this->assertIsObject($intention);
        $this->assertSame($this->mockFpayHttp->createPaymentIntention($data),$intention);
    }
    
    public function refundIntentionProvider():array
    {
        return [
            [
                "/checkout/payments/gateways/wallet/qr/intention-id/refund", [                    
                    "refunded_amount" => 1,                    
                    "refund_merchant_unique_id" => 'merchant-unique-id'                    
                ], [
                    "Content-Type" => "application/json",
                    "Authorization" => "Basic {$this->authSign}",
                    "fp-flow-country" => $this->country
                ]
            ]
        ];
    }

    /**
     * @dataProvider refundIntentionProvider
     *
     * @return void
     */
    public function testRefundIntentionException(string $url, array $data = [], array $headers = [])
    {
        $partialMockFpayHttp = $this->getMockBuilder(FpayHttp::class)
            ->setConstructorArgs([$this->mockClient, 'public_key', 'private_key'])
            ->onlyMethods(['addLog', 'getAuthToken', 'post', 'setOrderStatus'])
            ->getMock();
            
        $partialMockFpayHttp->orderId = $this->mockOrder->id;
        $partialMockFpayHttp->unitTest = true;

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('addLog');                            
        
        $partialMockFpayHttp
            ->expects($this->any())
            ->method('getAuthToken')
            ->willReturn('token');

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('setOrderStatus');            

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('post')
            ->willThrowException(
                new ClientException(
                    'Error en los datos',
                    new Request('GET', $url)
                )
            );      

        $this->expectException(ClientException::class);
        $partialMockFpayHttp->refundIntention(
            'intention-id',
            $data['refunded_amount'],
            $data['refund_merchant_unique_id']
        );
    }

    /**
     * @dataProvider refundIntentionProvider
     *
     * @return void
     */
    public function testRefundIntention(string $url, array $data = [], array $headers = [])
    {
        $partialMockFpayHttp = $this->getMockBuilder(FpayHttp::class)
            ->setConstructorArgs([$this->mockClient, 'public_key', 'private_key'])
            ->onlyMethods(['addLog', 'getAuthToken', 'post'])
            ->getMock();
        $partialMockFpayHttp->orderId = $this->mockOrder->id;

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('addLog');            

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('getAuthToken')
            ->willReturn('token');

        $response = Stream::factory(json_encode($this->testIntentionData));

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('post')         
            ->willReturn(new Response(200,[],
                $response
            ));      

        $intention = $partialMockFpayHttp->refundIntention(
            'intention-id',
            $data['refunded_amount'],
            $data['refund_merchant_unique_id']
        );        

        $this->mockFpayHttp
            ->expects($this->any())
            ->method('refundIntention')
            ->willReturn($intention);

        $this->assertIsObject($intention);
        $this->assertSame($this->mockFpayHttp->refundIntention(
            'intention-id',
            $data['refunded_amount'],
            $data['refund_merchant_unique_id']
        ),$intention);
    }

    
    public function getIntentionProvider():array
    {
        return [
            [
                "/checkout/payments/intention-id", [], [
                    "Content-Type" => "application/json",
                    "Authorization" => "Basic {$this->authSign}",
                    "fp-flow-country" => $this->country
                ]
            ]
        ];
    }

    /**
     * @dataProvider getIntentionProvider
     *
     * @return void
     */
    public function testGetIntentionException(string $url, array $data = [], array $headers = [])
    {
        $partialMockFpayHttp = $this->getMockBuilder(FpayHttp::class)
            ->setConstructorArgs([$this->mockClient, 'public_key', 'private_key'])
            ->onlyMethods(['addLog', 'getAuthToken', 'get', 'setOrderStatus'])
            ->getMock();
            
        $partialMockFpayHttp->orderId = $this->mockOrder->id;
        $partialMockFpayHttp->unitTest = true;

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('addLog');                            
        
        $partialMockFpayHttp
            ->expects($this->any())
            ->method('getAuthToken')
            ->willReturn('token');

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('setOrderStatus');            

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('get')
            ->willThrowException(
                new ClientException(
                    'Error en los datos',
                    new Request('GET', $url)
                )
            );      

        $this->expectException(ClientException::class);
        $partialMockFpayHttp->getIntention('intention-id');
    }

    /**
     * @dataProvider getIntentionProvider
     *
     * @return void
     */
    public function testGetIntention(string $url, array $data = [], array $headers = [])
    {
        $partialMockFpayHttp = $this->getMockBuilder(FpayHttp::class)
            ->setConstructorArgs([$this->mockClient, 'public_key', 'private_key'])
            ->onlyMethods(['addLog', 'getAuthToken', 'get'])
            ->getMock();
        $partialMockFpayHttp->orderId = $this->mockOrder->id;

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('addLog');            

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('getAuthToken')
            ->willReturn('token');

        $response = Stream::factory(json_encode($this->testIntentionData));

        $partialMockFpayHttp
            ->expects($this->any())
            ->method('get')         
            ->willReturn(new Response(200,[],
                $response
            ));      

        $intention = $partialMockFpayHttp->getIntention('intention-id');        

        $this->mockFpayHttp
            ->expects($this->any())
            ->method('getIntention')
            ->willReturn($intention);

        $this->assertIsObject($intention);
        $this->assertSame($this->mockFpayHttp->getIntention('intention-id'),$intention);
    }
    
    
    public function setOrderStatusProvider():array{
        return [
            [FpayStates::PAID],
            [FpayStates::REJECTED],
            [FpayStates::REFUNDED],
            ['default']
        ];
    }

    /**
     * @dataProvider setOrderStatusProvider
     */
    public function testSetOrderStatus(string $status)
    {   
        $this->mockFpayHttp
            ->expects($this->any())
            ->method('addLog')
            ->with('', false, 'setOrderStatus', 'Se ha iniciado una actualización de estado para la orden ' . $this->mockOrder->id);        

        $this->mockOrder
            ->expects($this->any())
            ->method('save')
            ->willReturn(true);
        
        $this->mockOrderHistory
            ->expects($this->any())
            ->method('save')
            ->willReturn(true);
        
        $orderStatus = $this->fpayHttp->setOrderStatus($status, $this->mockOrder, $this->mockOrderHistory);

        $this->mockFpayHttp
            ->expects($this->any())
            ->method('addLog')
            ->with('Estado actualizado a: ' . $orderStatus);

        $this->assertIsString($this->fpayHttp->setOrderStatus($status, $this->mockOrder, $this->mockOrderHistory));        
    }

    public function testGet(){
        $expectResponse = Stream::factory('ok');
        
        $this->mockClient
            ->expects($this->any())
            ->method('get')            
            ->willReturn(new Response(200,[],
                $expectResponse
            ));
        
        $response = $this->fpayHttp->get($this->fpayHttp->getApiUrl(), [
            'query' => [],
            'headers' => []
        ]);
        
        $this->assertSame($response->getStatusCode(),200);
        
    }
    
}
