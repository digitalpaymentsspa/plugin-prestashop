# Fpay
Módulo oficial para el CMS PrestaShop.

- Contributors: Falabella.cl
- Tags: Fpay, PrestaShop, payments, payment, Falabella
- Requires at least: 1.7.0.0
- Tested up to: 1.7.0.6
- Stable tag: 0.8
- Requires PHP: 7.1
- License: GPLv2 or later
- License URI: https://www.gnu.org/licenses/gpl-2.0.html

# Changelog
A continuación puede observar el registro de los cambios tras cada actualización.

= 1.0.0 =
▪ Fpay versión lite. 
