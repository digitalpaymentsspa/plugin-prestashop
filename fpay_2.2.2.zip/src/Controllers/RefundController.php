<?php

namespace PrestaShop\Module\Fpay\Controllers;

use Configuration;
use Context;
use CustomerMessage;
use CustomerThreadCore;
use Db;
use Exception;
use GuzzleHttp\Client;
use Order;
use OrderHistory;
use PrestaShop\Module\Fpay\Classes\FpayGatewayPayment;
use PrestaShop\Module\Fpay\Classes\FpayHttp;
use PrestaShop\Module\Fpay\Constants\FpayStates;
use PrestaShop\PrestaShop\Core\Domain\Order\Command\IssuePartialRefundCommand;
use PrestaShop\PrestaShop\Core\Domain\Order\VoucherRefundType;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use PrestaShopBundle\Form\Admin\Product\ProductPrice;

class RefundController extends FrameworkBundleAdminController
{
    private $dataLog = "";

    /**
     * Initializes common front page content: header, footer and side columns.
     * Process Processes the result of the refund made with Fpay
     *
     * @return void
     */
    public function index()
    {
        //Get config fpay
        $config = Configuration::getMultiple(array('FPAY_PRIVATE_KEY', 'FPAY_PUBLIC_KEY'));
        if (!empty($config['FPAY_PUBLIC_KEY'])) {
            $this->publicKey = $config['FPAY_PUBLIC_KEY'];
        }
        if (!empty($config['FPAY_PRIVATE_KEY'])) {
            $this->privateKey = $config['FPAY_PRIVATE_KEY'];
        }
        $fpayGatewayPayment = new FpayGatewayPayment(
            new FpayHttp(new Client(), $this->publicKey, $this->privateKey)
        );
        //start log tracking
        $fpayGatewayPayment->addLog('', true, 'RefundController', 'Se ha iniciado el procesamiento de los reembolsos pendientes realizados desde Fpay.');

        // Run sql for creating intention tracking
        $db = Db::getInstance(_PS_USE_SQL_SLAVE_);
        $pendingUpdate = $db->executeS("SELECT * FROM `" . _DB_PREFIX_ . "fpay`");
        $message = "No hay datos pendientes por procesar";
        if ($pendingUpdate) {
            $this->processPending($pendingUpdate, $db, $fpayGatewayPayment);
            $db->execute("ALTER TABLE `" . _DB_PREFIX_ . "fpay` auto_increment = 1;");
        } else {
            $fpayGatewayPayment->addLog($message);
        }
        $fpayGatewayPayment->logger();

        header("Location: " . $fpayGatewayPayment->getSiteUrl(true) . ltrim($_GET['refer'], '/'));
        exit();
    }

    private function processPending(array $pendingUpdate, Db $db, FpayGatewayPayment $fpayGatewayPayment)
    {
        foreach ($pendingUpdate as $data) {
            $intentionId = $data['intention_id'];

            $fpayIntention = $fpayGatewayPayment->getIntention($intentionId);

            if ($fpayIntention && in_array($fpayIntention->pst_origen, ["PrestaShop", "Prestashop", "prestashop"]) && $data['order_id'] == $fpayIntention->transaction->purchase_order) {
                $order =  new Order($fpayIntention->transaction->purchase_order);
                $payment = $order->getOrderPaymentCollection();
                $orderDetails = $order->getOrderDetailList();
                if ($payment[0]->transaction_id == $intentionId) {
                    $refundedAmount = $fpayGatewayPayment->getRefundAmount($fpayIntention);
                    foreach ($orderDetails as $orderDetail) {
                        $quantityToRefund = (int)$orderDetail["product_quantity"] - (int)$orderDetail["product_quantity_refunded"];
                        if ($quantityToRefund>0 && $refundedAmount > 0) {
                            $productAmountAndQuantity = $this->getProductAmountAndQuantity($refundedAmount, $orderDetail, $fpayGatewayPayment);
                            $refundedAmount -= $productAmountAndQuantity[0];                            
                            $message = $this->makeRefund($orderDetail, $order, $fpayGatewayPayment, $productAmountAndQuantity, $fpayIntention);
                            $fpayGatewayPayment->addLog('Orden: ' . $data['order_id'] . ', Producto: '.$orderDetail['product_name'] .', '. $message);   
                        }else{
                            $refundedAmount -= (float)$orderDetail["total_refunded_tax_incl"];                            
                        }                        
                    }
                }
                $db->execute("DELETE FROM `" . _DB_PREFIX_ . "fpay` WHERE `order_id` = '" . $data['order_id'] . "' AND `intention_id` = '" . $data['intention_id'] . "';");
            }
        }
    }

    /**
     * make refund in prestashop
     *
     * @param float|integer $refundedAmount
     * @param array $orderDetail
     * @param Order $order
     * @param FpayGatewayPayment $fpayGatewayPayment
     * @param array $productAmountAndQuantity 
     * @param mixed $fpayIntention
     * @return void
     */
    public function makeRefund(array $orderDetail, Order $order, FpayGatewayPayment $fpayGatewayPayment, array $productAmountAndQuantity, $fpayIntention)
    {        
        if ($productAmountAndQuantity[0] > 0) {
            $quantity = $productAmountAndQuantity[1];
            if ((float)$orderDetail["total_refunded_tax_incl"] == (float)$orderDetail["total_price_tax_incl"]) {
                $message = "Este detalle de orden ya fue reembolsado por completo";
            } else {
                $fpayGatewayPayment->addLog('', false, 'makeRefund', 'Se realiza un reembolso de un producto desde Fpay.');
                // Instantiate the corresponding command
                try {
                    $command = new IssuePartialRefundCommand(
                        $order->id,
                        [
                            $orderDetail["id_order_detail"] => [
                                'quantity' => $quantity, 'amount' => $productAmountAndQuantity[0]
                            ],
                        ],
                        "0",true,false,true,
                        VoucherRefundType::SPECIFIC_AMOUNT_REFUND,
                        (string) $productAmountAndQuantity[0]
                    );

                    Context::getContext()->cookie->__set('fpayWebHookRefund','1');
                    Context::getContext()->cookie->write();
                    // Give it to the command busservice
                    $this->getCommandBus()->handle($command);

                    $fpayGatewayPayment->addLog(json_encode($command));
                    $fpayGatewayPayment->logger();

                    $fpayGatewayPayment->setOrderStatus(FpayStates::REFUNDED, $order, new OrderHistory());
                    $fpayGatewayPayment->createMessage($fpayIntention, $order, $productAmountAndQuantity, $orderDetail, 'Reembolso realizado desde Fpay');
                    $message =  "Reembolso realizado con éxito";
                } catch (Exception $th) {
                    $message = $th->getMessage() != "" ? $th->getMessage() : "Los productos reingresados deben ser mayores que 0";
                    $fpayGatewayPayment->addLog($message);
                    $fpayGatewayPayment->logger();
                }
            }
        }
        return $message;
    }

    public function getProductAmountAndQuantity(float $refundedAmount, array $orderDetail, FpayGatewayPayment $fpayGatewayPayment)
    {
        $productPrice = (float)$orderDetail["total_price_tax_incl"] / (int)$orderDetail['product_quantity'];
        $quantityToRefund = (int)$orderDetail["product_quantity"] - (int)$orderDetail["product_quantity_refunded"];        
        $productAmountToRefund = 0;
        if ($productPrice<=$refundedAmount) {
            for ($i=$quantityToRefund; $i > 0; $i--) { 
                $productAmountToRefund = $i * $productPrice;    
                if ($productAmountToRefund<=$refundedAmount) {
                    $quantityToRefund = $i;
                    break;
                }
            }
        }else{
            $fpayGatewayPayment->addLog("El valor del reembolso realizado en Fpay no es suficiente para cubrir el precio del producto.\n Este quedará a espera de un reembolso mayor para realizar la actualización en prestashop.");
        }
        return [$productAmountToRefund, $quantityToRefund];
    }    
}
