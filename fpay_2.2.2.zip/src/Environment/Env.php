<?php

namespace PrestaShop\Module\Fpay\Environment;

use Configuration;
use Dotenv\Dotenv;
use PrestaShop\Module\Fpay\Contracts\Environment\EnvEnvironment;

/**
 * Get the current environment used: prod or test // sandbox or live
 */
class Env implements EnvEnvironment
{
    /**
     * Const that define all environment possible to use.
     * Top of the list are taken in first if they exist in the project.
     * eg: If .env.test is present in the module it will be loaded, if not present
     * we try to load the next one etc ...
     *
     * @var array
     */
    const FILE_ENV_LIST = [        
        'test' => '.noEnv',
        'prod' => '.env',
    ];

    /**
     * Concatenated data to be stored in the log
     *
     * @var string
     */
    private $dataLog = '';

    /**
     * Environment name: can be 'prod'
     *
     * @var string
     */
    protected $name;

    /**
     * Environment mode: can be 'prod' or 'test'
     *
     * @var bool
     */
    protected $mode;

    public function __construct()
    {
        foreach (self::FILE_ENV_LIST as $env => $fileName) {
            if (!file_exists(_PS_MODULE_DIR_ . 'fpay/' . $fileName)) {
                continue;
            }

            $dotenv = Dotenv::create(_PS_MODULE_DIR_ . 'fpay', $fileName);            
            $dotenv->load();

            $this->setName($env);

            break;
        }
        
        $this->isLive() === true ? $this->setMode(true) : $this->setMode(false);        
    }

    /**
     * Check if the module is in SANDBOX or LIVE mode
     *
     * @return bool true if the module is in LIVE mode
     */
    private function isLive()
    { 
        $isLive = Configuration::get(
            'FPAY_TEST_MODE',
            false 
        );

        return (bool)$isLive;
    }

    public function getName()
    {
        return $this->name;
    }
    
    public function getMode()
    {
        return $this->mode;
    }

    /**
     * setter for name
     *
     * @param string $name
     */
    private function setName($name)
    {
        $this->name = $name;
    }

    /**
     * setter for mode
     *
     * @param bool $mode
     */
    private function setMode(bool $mode)
    {
        $this->mode = $mode;
    }
    
    public function addLog(string $data = '', bool $currentDate = false, string $functionOrVar = '', string $description = '')
    {
        if ($currentDate) {
            $this->dataLog .= PHP_EOL."************************************";
            $this->dataLog .= PHP_EOL."********* ".date('d/m/Y H:i:s')." *********";
            $this->dataLog .= PHP_EOL."************************************";
        }
        if (trim($functionOrVar)!='') {
            $this->dataLog .= PHP_EOL."$functionOrVar (".date('H:i:s').")";
            if (trim($description)!='') {
                $this->dataLog .= " ::::: $description";
            }
        }
        if (trim($data)!='') {
            $this->dataLog .= PHP_EOL."$data";
        }
    }

    /**
     * Write over the daily log file
     *     
     * @return void
     */
    public function logger(){
        file_put_contents(_PS_MODULE_DIR_.'fpay/src/logs/log-'.date('Y-m-d').'.txt', $this->dataLog."".PHP_EOL , FILE_APPEND | LOCK_EX);                        
        $this->dataLog = '';
    }
}