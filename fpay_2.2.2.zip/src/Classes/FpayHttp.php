<?php

namespace PrestaShop\Module\Fpay\Classes;

use Context;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\RequestException;
use Order;
use OrderHistory;
use PrestaShop\Module\Fpay\Constants\FpayErrors;
use PrestaShop\Module\Fpay\Constants\FpayStates;
use PrestaShop\Module\Fpay\Contracts\Classes\FpayHttpClass;
use PrestaShop\Module\Fpay\Environment\FpayEnv;
use Tools;

class FpayHttp extends FpayEnv implements FpayHttpClass
{    
    /**
     * http client Http client to make curl calls
     *
     * @var Client
     */
    private Client $http;

    /**
     * FPay Merchant Public Key
     *
     * @var string|null
     */
    private $publicKey;

    /**
     * FPay Merchant Private Key
     *
     * @var string|null
     */
    private $privateKey;

    /**
     * Application/Json http Header
     *
     * @var string
     */
    private $applicationJson = "application/json";

    /**
     * Order detail url for exception errors
     *
     * @var string
     */
    private $orderDetailUrl = "index.php?controller=order-detail&id_order=";


    /**
     * Prestashop order id
     *
     * @var int
     */
    public $orderId;    

    public $unitTest = false;

    public function __construct(Client $http, $publicKey, $privateKey)
    {
        parent::__construct();
        $this->publicKey = $publicKey;
        $this->privateKey = $privateKey;
        $this->http = $http;
    }

    public function getAuthToken()
    {
        $authSign = $this->publicKey . ":" . $this->privateKey;
        try {
            $response =  $this->post("/sso/oauth2/v2/token", [
                "grant_type" => "client_credentials"
            ], [
                "Content-Type" => $this->applicationJson,
                "Authorization" => "Basic $authSign",
                "fp-flow-country" => $this->getCountryCode()
            ]);
        } catch (ClientException $e) {
            $this->addLog('', false, 'getAuthToken', 'Se intentó realizar la autenticación en Fpay sin éxito.');
            $this->addLog(FpayErrors::CREDENTIALS . ': Error al intentar autenticarse en Fpay: ' . $e->getMessage());
            $this->logger();
            $this->setOrderStatus(FpayStates::VOIDED, new Order($this->orderId), new OrderHistory());
            Context::getContext()->cookie->fpayError = FpayErrors::CREDENTIALS . ': Error al intentar autenticarse en Fpay, comuníquese con nuestra tienda para informar este error.';
            !$this->unitTest ? Tools::redirect($this->orderDetailUrl . $this->orderId) : null;
            throw $e;
        }        
        return $this->toObject($response->json())->access_token;
    }

    public function createPaymentIntention(array $data)
    {
        $token = $this->getAuthToken();
        $this->addLog('', false, 'createPaymentIntention', 'Se ha iniciado la creación de una intención de pago en Fpay.');

        try {
            $response = $this->post("/checkout/payments", $data, [
                "Content-Type" => $this->applicationJson,
                "Authorization" => "Bearer $token",
                "fp-flow-country" => $this->getCountryCode()
            ]);
        } catch (ClientException $e) {
            $this->addLog(FpayErrors::CREATE_INTENTION . ': Error al intentar crear la intención de pago en Fpay: ' . $e->getMessage());
            $this->logger();
            $this->setOrderStatus(FpayStates::VOIDED, new Order($this->orderId), new OrderHistory());
            Context::getContext()->cookie->fpayError = FpayErrors::CREATE_INTENTION . ': Error al intentar crear la intención de pago en Fpay';
            !$this->unitTest ? Tools::redirect($this->orderDetailUrl . $this->orderId) : null;
            throw $e;
        }

        $this->addLog(json_encode($response->json()));
        $this->logger();

        return $this->toObject($response->json());
    }

    public function refundIntention(string $intentionId, int $refundedAmount, string $merchantUniqueId)
    {
        $token = $this->getAuthToken();
        $this->addLog('', false, 'refundIntention', 'Se ha iniciado un reembolso desde PrestaShop a Fpay');

        try {
            $response = $this->post("/checkout/payments/gateways/wallet/qr/$intentionId/refund", [
                "refunded_amount" => $refundedAmount,
                "refund_merchant_unique_id" => $merchantUniqueId
            ], [
                "Content-Type" => $this->applicationJson,
                "Authorization" => "Bearer $token",
                "fp-flow-country" => $this->getCountryCode()
            ]);
        } catch (ClientException $e) {
            $this->addLog(FpayErrors::REFUND . ': Error al intentar hacer el reembolso en Fpay: ' . $e->getMessage());
            $this->logger();
            $this->setOrderStatus(FpayStates::VOIDED, new Order($this->orderId), new OrderHistory());
            Context::getContext()->cookie->fpayError = FpayErrors::REFUND . ': Error al intentar hacer el reembolso en Fpay';
            !$this->unitTest ? Tools::redirect($this->orderDetailUrl . $this->orderId) : null;
            throw $e;
        }

        $this->addLog(json_encode($response->json()));
        $this->logger();

        return $this->toObject($response->json());
    }

    public function getIntention(string $intentionId)
    {
        $token = $this->getAuthToken();
        $this->addLog('', false, 'getIntention', 'Se ha solicitado la información de una intención de pago en Fpay.');

        try {
            $response = $this->get("/checkout/payments/$intentionId", [], [
                "Content-Type" => $this->applicationJson,
                "Authorization" => "Bearer $token",
                "fp-flow-country" => $this->getCountryCode()
            ]);
        } catch (ClientException $e) {
            $this->addLog(FpayErrors::GET_INTENTION . ': Error al intentar obtener la intención de pago en Fpay: ' . $e->getMessage());
            $this->logger();
            $this->setOrderStatus(FpayStates::VOIDED, new Order($this->orderId), new OrderHistory());
            Context::getContext()->cookie->fpayError = FpayErrors::GET_INTENTION . ': Error al intentar obtener la intención de pago en Fpay';
            !$this->unitTest ? Tools::redirect($this->orderDetailUrl . $this->orderId) : null;
            throw $e;
        }

        $this->addLog(json_encode($response->json()));
        $this->logger();

        return $this->toObject($response->json());
    }

    public function post(string $url, array $data = [], array $headers = [])
    {
        return $this->http->post($this->getApiUrl() . $url, [
            'body' => json_encode($data),
            'headers' => $headers
        ]);
    }

    public function get(string $url, array $data = [], array $headers = [])
    {
        return $this->http->get($this->getApiUrl() . $url, [
            'query' => $data,
            'headers' => $headers
        ]);
    }

    public function setOrderStatus(string $fpayState, Order $order, OrderHistory $history)
    {
        $status = 'error';
        if ($this->orderId) {
            $status = $this->setOrderStatusCase($fpayState, $order, $history);
        }
        return $status;
    }

    private function setOrderStatusCase(string $fpayState, Order $order, OrderHistory $history)
    {
        $status = 'error';
        $this->orderId = $order->id;
        $this->addLog('', false, 'setOrderStatus', 'Se ha iniciado una actualización de estado para la orden ' . $order->id);
        $history->id_order = (int)$this->orderId;
        $saveHistory = true;
        switch (true) {
            case in_array($fpayState, [FpayStates::PAID]):
                if ($order->current_state != _PS_OS_PAYMENT_) {
                    $order->current_state = _PS_OS_PAYMENT_;
                    $order->save();
                    $history->id_order_state = _PS_OS_PAYMENT_;
                } else {
                    $saveHistory = false;
                }
                $status =  'success';
                break;
            case in_array($fpayState, [FpayStates::REJECTED, FpayStates::VOIDED, FpayStates::EXPIRED]):
                if ($order->current_state != _PS_OS_ERROR_) {
                    $order->current_state = _PS_OS_ERROR_;
                    $order->save();
                    $history->id_order_state = _PS_OS_ERROR_;
                } else {
                    $saveHistory = false;
                }
                $status = 'error';
                break;
            case in_array($fpayState, [FpayStates::REFUNDED, FpayStates::REVERSED, FpayStates::PARTIALLY_REFUNDED]):
                if ($order->current_state != _PS_OS_REFUND_) {
                    $order->current_state = _PS_OS_REFUND_;
                    $order->save();
                    $history->id_order_state = _PS_OS_REFUND_;
                } else {
                    $saveHistory = false;
                }
                $status =  'refunded';
                break;
            default:
                if ($order->current_state != _PS_OS_CANCELED_) {
                    $order->current_state = _PS_OS_CANCELED_;
                    $order->save();
                    $history->id_order_state = _PS_OS_CANCELED_;
                    $status = 'error';
                } else {
                    $saveHistory = false;
                }
                break;
        }
        if ($saveHistory) {
            $history->save();
            $this->addLog('Estado actualizado a: ' . $status);
        }
        return $status;
    }


    /**
     * Parse array to stdClass
     *
     * @param array $array
     * @return stdClass
     */
    private function toObject(array $array)
    {
        return json_decode(json_encode($array));
    }
}
