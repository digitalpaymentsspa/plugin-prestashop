<?php

namespace PrestaShop\Module\Fpay\Constants;

/**
 * This class contains the fpay states
 */
class FpayStates{
    const PAID = 'paid';
    const CREATED = 'created';
    const CANCELED = 'canceled';
    const REFUNDED = 'refunded';
    const REVERSED = 'reversed';
    const PARTIALLY_REFUNDED = 'partially_refunded';
    const REJECTED = 'rejected';
    const VOIDED = 'voided';
    const EXPIRED = 'expired';
}