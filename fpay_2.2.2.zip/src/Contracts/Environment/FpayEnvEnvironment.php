<?php

namespace PrestaShop\Module\Fpay\Contracts\Environment;

/**
 * Allow to set the differents api key / api link depending on
 */
interface FpayEnvEnvironment
{   

    /**
     * getter for apiUrl
     * 
     * @return string $apiUrl
     */
    public function getApiUrl();

    /**
     * getter for countryCode
     *
     * @return string $countryCode
     */
    public function getCountryCode();

    /**
     * getter for currency
     *
     * @return string $currency
     */
    public function getCurrency();

    /**
     * getter for documentType
     *
     * @return string $documentType
     */
    public function getDocumentType();

    /**
     * getter for paymentMethod
     *
     * @return string $paymentMethod
     */
    public function getPaymentMethod();

    /**
     * getter for pstOrigen
     *
     * @return string $pstOrigen
     */
    public function getPstOrigen();

    /**
     * getter for version
     *
     * @return string $version
     */
    public function getVersion();

    /**
     * getter for softDescriptor
     *
     * @return string $softDescriptor
     */
    public function getSoftDescriptor();

    /**
     * getter for merchantFantasyName
     *
     * @return string $merchantFantasyName
     */
    public function getMerchantFantasyName();

    /**
     * getter for invoiceType
     *
     * @return string $invoiceType
     */
    public function getInvoiceType();

    /**
     * getter for shippingMethod
     *
     * @return string $shippingMethod
     */
    public function getShippingMethod();

    /**
     * getter for channel
     *
     * @return string $channel
     */
    public function getChannel();
}