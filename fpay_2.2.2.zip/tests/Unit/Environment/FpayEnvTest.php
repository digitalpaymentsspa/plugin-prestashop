<?php

declare(strict_types=1);

namespace Tests\Unit\FpayEnvironment;

use PrestaShop\Module\Fpay\Environment\FpayEnv;
use Tests\BaseTest;

class FpayEnvTest extends BaseTest
{
    
    protected FpayEnv $fpayEnv;    

    protected function setUp(): void
    {
        $this->fpayEnv = new FpayEnv();
    }

    /**
     * Check if class file exists
     *                                                                                                                                                                                                                  
     * @return void
     */
    public function testFileExists()
    {
        $filePath = _PS_MODULE_DIR_ . 'fpay/src/Environment/FpayEnv.php';
        $exists = file_exists($filePath);
        $this->assertTrue($exists);
    }
    
    public function testClassConstructor()
    {
        $this->assertInstanceOf(FpayEnv::class, $this->fpayEnv);        
    }
    
    public function testGetApiUrl(){
        $this->assertIsString($this->fpayEnv->getApiUrl());
    }

    public function testGetCountryCode(){
        $this->assertIsString($this->fpayEnv->getCountryCode());
    }

    public function testGetCurrency(){
        $this->assertIsString($this->fpayEnv->getCurrency());
    }

    public function testGetDocumentType(){
        $this->assertIsString($this->fpayEnv->getDocumentType());
    }

    public function testGetPaymentMethod(){
        $this->assertIsString($this->fpayEnv->getPaymentMethod());
    }

    public function testGetPstOrigen(){
        $this->assertIsString($this->fpayEnv->getPstOrigen());
    }

    public function testGetVersion(){
        $this->assertIsString($this->fpayEnv->getVersion());
    }

    public function testGetSoftDescriptor(){
        $this->assertIsString($this->fpayEnv->getSoftDescriptor());
    }

    public function testGetMerchantFantasyName(){
        $this->assertIsString($this->fpayEnv->getMerchantFantasyName());
    }

    public function testGetInvoiceType(){
        $this->assertIsString($this->fpayEnv->getInvoiceType());
    }

    public function testGetShippingMethod(){
        $this->assertIsString($this->fpayEnv->getShippingMethod());
    }

    public function testGetChannel(){
        $this->assertIsString($this->fpayEnv->getChannel());
    }

    
}
