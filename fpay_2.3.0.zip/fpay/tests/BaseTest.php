<?php

namespace Tests;
require_once __DIR__ . '/../../../config/config.inc.php';
require_once _PS_MODULE_DIR_ . 'fpay/vendor/autoload.php';
error_reporting(0);  
use PHPUnit\Framework\TestCase;

class BaseTest extends TestCase{
    
    /**
     * Test path folder
     */
    const FPAY_TEST_DIR = _PS_MODULE_DIR_. 'fpay/tests/Unit/';        

    public function testTrueIsTrue()
    {
        $this->assertTrue(true);
    }
}