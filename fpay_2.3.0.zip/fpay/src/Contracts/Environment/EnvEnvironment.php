<?php

namespace PrestaShop\Module\Fpay\Contracts\Environment;

/**
 * Get the current environment used: prod or test // sandbox or live
 */
interface EnvEnvironment
{    
    /**
     * getter for name
     */
    public function getName();

    /**
     * getter for mode
     */
    public function getMode();

    /**
     * Add data for log
     *
     * @param string $data
     * @param boolean $currentDate
     * @param string $functionOrVar
     * @param string $description of functionOrVar
     * @return void
     */
    public function addLog(string $data = '', bool $currentDate = false, string $functionOrVar = '', string $description = '');

    /**
     * Write over the daily log file
     *     
     * @return void
     */
    public function logger();
}