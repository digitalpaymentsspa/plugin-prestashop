<?php

namespace PrestaShop\Module\Fpay\Controllers;

use Configuration;
use Context;
use CustomerMessage;
use CustomerThreadCore;
use Db;
use Exception;
use GuzzleHttp\Client;
use Order;
use OrderHistory;
use PrestaShop\Module\Fpay\Classes\FpayGatewayPayment;
use PrestaShop\Module\Fpay\Classes\FpayHttp;
use PrestaShop\Module\Fpay\Constants\FpayErrors;
use PrestaShop\Module\Fpay\Constants\FpayStates;
use PrestaShop\PrestaShop\Core\Domain\Order\Command\IssuePartialRefundCommand;
use PrestaShop\PrestaShop\Core\Domain\Order\VoucherRefundType;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;

class WebHookController extends FrameworkBundleAdminController
{

    /**
     * Initializes common front page content: header, footer and side columns.
     * Process Processes the result of the intention made with Fpay
     *
     * @return void
     */
    public function index()
    {
        //Get config fpay
        $config = Configuration::getMultiple(array('FPAY_PRIVATE_KEY', 'FPAY_PUBLIC_KEY'));
        if (!empty($config['FPAY_PUBLIC_KEY'])) {
            $this->publicKey = $config['FPAY_PUBLIC_KEY'];
        }
        if (!empty($config['FPAY_PRIVATE_KEY'])) {
            $this->privateKey = $config['FPAY_PRIVATE_KEY'];
        }
        $fpayGatewayPayment = new FpayGatewayPayment(
            new FpayHttp(new Client(), $this->publicKey, $this->privateKey)
        );
        //start log tracking
        $fpayGatewayPayment->addLog(
            '',
            true,
            'WebHookController',
            'Se ha iniciado el procesamiento de las intenciones pendientes desde Fpay.'
        );

        // Run sql for creating intention tracking
        $db = Db::getInstance(_PS_USE_SQL_SLAVE_);
        $pendingUpdate = $db->executeS("SELECT * FROM `" . _DB_PREFIX_ . "fpay`");
        $message = "No hay datos pendientes por procesar";
        if ($pendingUpdate) {
            $this->processPending($pendingUpdate, $db, $fpayGatewayPayment);
            $db->execute("ALTER TABLE `" . _DB_PREFIX_ . "fpay` auto_increment = 1;");
        } else {
            $fpayGatewayPayment->addLog($message);
        }
        $fpayGatewayPayment->logger();

        header("Location: " . $fpayGatewayPayment->getSiteUrl(true) . ltrim($_GET['refer'], '/'));
        exit();
    }

    private function processPending(array $pendingUpdate, Db $db, FpayGatewayPayment $fpayGatewayPayment)
    {
        foreach ($pendingUpdate as $data) {
            $intentionId = $data['intention_id'];

            $fpayIntention = $fpayGatewayPayment->getIntention($intentionId);

            if ($fpayIntention && in_array(
                $fpayIntention->pst_origen,
                ["PrestaShop", "Prestashop", "prestashop"]
            ) && $data['order_id'] == $fpayIntention->transaction->purchase_order) {
                $order =  new Order($fpayIntention->transaction->purchase_order);
                $payment = $order->getOrderPaymentCollection()->getFirst();
                $orderDetails = $order->getOrderDetailList();
                if ($payment && $payment->transaction_id == $intentionId) {
                    $this->processByState($fpayGatewayPayment, $fpayIntention, $order, $orderDetails, $data);
                }
                $db->execute(
                    "DELETE FROM `" . _DB_PREFIX_ . "fpay` " .
                        "WHERE `order_id` = '" . $data['order_id'] . "' " .
                        "AND `intention_id` = '" . $data['intention_id'] . "';"
                );
            }
        }
    }

    /**
     * Process refunds
     *
     * @param FpayGatewayPayment $fpayGatewayPayment
     * @param mixed $fpayIntention
     * @param Order $order
     * @param array $orderDetails
     * @param array $data
     */
    public function processByState(
        FpayGatewayPayment $fpayGatewayPayment,
        $fpayIntention,
        Order $order,
        array $orderDetails,
        array $data
    ) {
        if (in_array(
            $fpayIntention->state,
            [FpayStates::REFUNDED, FpayStates::REVERSED, FpayStates::PARTIALLY_REFUNDED]
        )) {
            $this->processRefunds($fpayGatewayPayment, $fpayIntention, $order, $orderDetails, $data);
        } else {
            $fpayGatewayPayment->setOrderStatus($fpayIntention->state, $order, new OrderHistory());
            $this->createMessage($fpayIntention, $order);
        }
    }

    /**
     * Process refunds
     *
     * @param FpayGatewayPayment $fpayGatewayPayment
     * @param mixed $fpayIntention
     * @param Order $order
     * @param array $orderDetails
     * @param array $data
     * @return void
     */
    public function processRefunds(
        FpayGatewayPayment $fpayGatewayPayment,
        $fpayIntention,
        Order $order,
        array $orderDetails,
        array $data
    ) {
        $refundedAmount = $fpayGatewayPayment->getRefundAmount($fpayIntention);
        foreach ($orderDetails as $orderDetail) {
            $quantityToRefund = (int)$orderDetail["product_quantity"] -
                (int)$orderDetail["product_quantity_refunded"];
            if ($quantityToRefund > 0 && $refundedAmount > 0) {
                $productAmountAndQuantity =
                    $this->getProductAmountAndQuantity($refundedAmount, $orderDetail, $fpayGatewayPayment);
                $refundedAmount -= $productAmountAndQuantity[0];
                $message = $this->makeRefund(
                    $orderDetail,
                    $order,
                    $fpayGatewayPayment,
                    $productAmountAndQuantity,
                    $fpayIntention
                );
                $fpayGatewayPayment->addLog(
                    'Orden: ' . $data['order_id'] . ', ' .
                        'Producto: ' . $orderDetail['product_name'] . ', ' . $message
                );
            } else {
                $refundedAmount -= (float)$orderDetail["total_refunded_tax_incl"];
            }
        }
    }

    /**
     * make refund in prestashop
     *
     * @param float|integer $refundedAmount
     * @param array $orderDetail
     * @param Order $order
     * @param FpayGatewayPayment $fpayGatewayPayment
     * @param array $productAmountAndQuantity
     * @param mixed $fpayIntention
     * @return void
     */
    public function makeRefund(
        array $orderDetail,
        Order $order,
        FpayGatewayPayment $fpayGatewayPayment,
        array $productAmountAndQuantity,
        $fpayIntention
    ) {
        if ($productAmountAndQuantity[0] > 0) {
            if ((float)$orderDetail["total_refunded_tax_incl"] == (float)$orderDetail["total_price_tax_incl"]) {
                $message = "Este detalle de orden ya fue reembolsado por completo";
            } else {
                $fpayGatewayPayment->addLog(
                    '',
                    false,
                    'makeRefund',
                    'Se realiza un reembolso de un producto desde Fpay.'
                );
                // Instantiate the corresponding command
                $message = $this->handleRefundCommand(
                    $fpayGatewayPayment,
                    $fpayIntention,
                    $order,
                    $orderDetail,
                    $productAmountAndQuantity
                );
            }
        }
        return $message;
    }

    /**
     * Run refund prestashop command
     *
     * @param FpayGatewayPayment $fpayGatewayPayment
     * @param mixed $fpayIntention
     * @param Order $order
     * @param array $orderDetail
     * @param array $productAmountAndQuantity
     * @return void
     */
    public function handleRefundCommand(
        FpayGatewayPayment $fpayGatewayPayment,
        $fpayIntention,
        Order $order,
        array $orderDetail,
        array $productAmountAndQuantity
    ) {
        try {
            $command = new IssuePartialRefundCommand(
                $order->id,
                [
                    $orderDetail["id_order_detail"] => [
                        'quantity' => $productAmountAndQuantity[1], 'amount' => $productAmountAndQuantity[0]
                    ],
                ],
                "0",
                true,
                false,
                true,
                VoucherRefundType::SPECIFIC_AMOUNT_REFUND,
                (string) $productAmountAndQuantity[0]
            );

            Context::getContext()->cookie->__set('fpayWebHookRefund', '1');
            Context::getContext()->cookie->write();
            // Give it to the command busservice
            $this->getCommandBus()->handle($command);

            $fpayGatewayPayment->addLog(json_encode($command));
            $fpayGatewayPayment->logger();

            $fpayGatewayPayment->setOrderStatus(FpayStates::REFUNDED, $order, new OrderHistory());
            $fpayGatewayPayment->createMessage(
                $fpayIntention,
                $order,
                $productAmountAndQuantity,
                $orderDetail,
                'Reembolso realizado desde Fpay'
            );
            $message =  "Reembolso realizado con éxito";
        } catch (Exception $th) {
            $message = $th->getMessage() != "" ?
                $th->getMessage() :
                "Los productos reingresados deben ser mayores que 0";
            $fpayGatewayPayment->addLog($message);
            $fpayGatewayPayment->logger();
        }
        return $message;
    }

    /**
     * Get product amount and quantity for refund
     *
     * @param float $refundedAmount
     * @param array $orderDetail
     * @param FpayGatewayPayment $fpayGatewayPayment
     * @return array
     */
    public function getProductAmountAndQuantity(
        float $refundedAmount,
        array $orderDetail,
        FpayGatewayPayment $fpayGatewayPayment
    ) {
        $productPrice = (float)$orderDetail["total_price_tax_incl"] / (int)$orderDetail['product_quantity'];
        $quantityToRefund = (int)$orderDetail["product_quantity"] - (int)$orderDetail["product_quantity_refunded"];
        $productAmountToRefund = 0;
        if ($productPrice <= $refundedAmount) {
            for ($i = $quantityToRefund; $i > 0; $i--) {
                $productAmountToRefund = $i * $productPrice;
                if ($productAmountToRefund <= $refundedAmount) {
                    $quantityToRefund = $i;
                    break;
                }
            }
        } else {
            $fpayGatewayPayment->addLog(
                "El valor del reembolso realizado en Fpay no es suficiente para cubrir el precio del producto." .
                    "\n Este quedará a espera de un reembolso mayor para realizar la actualización en prestashop."
            );
        }
        return [$productAmountToRefund, $quantityToRefund];
    }

    /**
     * Create order status message for customer
     *
     * @param mixed|null $fpayIntention
     * @param Order $order
     * @return void
     */
    private function createMessage($fpayIntention, Order $order)
    {

        $transactionDetails = FpayErrors::PAID . ': Error al realizar el pago con Fpay.';
        if (isset($fpayIntention->transaction)) {

            $date = date('Y-m-d H:i:s', strtotime($fpayIntention->create_time));

            $transactionDetails = "
			Estado: {$fpayIntention->state} \n
			Total: {$fpayIntention->transaction->amount->total} {$fpayIntention->transaction->amount->currency} \n
			Tipo de Pago: {$fpayIntention->payment_method} \n
			Nº de Cuotas: {$fpayIntention->transaction->amount->installments_number} \n
			Fecha: $date \n
			Transacción Nº: {$fpayIntention->_id} \n
			Orden N°: {$fpayIntention->transaction->purchase_order} \n
            ";
        }

        $thread = CustomerThreadCore::getCustomerMessages($order->id_customer, null, $order->id);

        if (empty($thread)) {
            $customerThread = new CustomerThreadCore();
            $customerThread->id_order = $order->id;
            $customerThread->id_customer = $order->id_customer;
            $customerThread->id_lang = 1;
            $customerThread->token = "FPAY-{$order->id}";
            $customerThread->id_contact = 0;
            $customerThread->save();

            $threadId = $customerThread->id;
            $messageId = null;
        } else {
            $threadId = $thread[0]['id_customer_thread'];
            $messageId = $thread[0]['id_customer_message'];
        }

        $orderMessage = new CustomerMessage($messageId);
        $orderMessage->id_order = (int)$order->id;
        $orderMessage->id_customer_thread = $threadId;
        $orderMessage->message = $transactionDetails;
        $orderMessage->private = true;
        $orderMessage->save();
    }
}
