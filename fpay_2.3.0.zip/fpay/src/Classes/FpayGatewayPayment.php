<?php

namespace PrestaShop\Module\Fpay\Classes;

use Address;
use CustomerMessage;
use CustomerThreadCore;
use Db;
use Order;
use OrderHistory;
use PrestaShop\Module\Fpay\Constants\FpayStates;
use PrestaShop\Module\Fpay\Contracts\Classes\FpayGatewayPaymentClass;
use PrestaShop\PrestaShop\Adapter\SymfonyContainer;
use PrestaShopCollection;

/**
 * Fpay gateway class
 */
class FpayGatewayPayment implements FpayGatewayPaymentClass
{
    /**
     * Http api fpay
     *
     * @var FpayHttp
     */
    private FpayHttp $http;

    /**
     * Fpay module version
     *
     * @var string
     */
    public $version = '';

    public function __construct(FpayHttp $http)
    {
        $this->http = $http;
        $this->version = $this->http->getVersion();
    }

    public function processPayment(Order $order, Address $address)
    {
        //start log tracking
        $this->addLog('', true, 'processPayment', 'Se ha iniciado un proceso de pago con Fpay.');
        //get order products
        $products = $order->hasPayments() ? $order->getProductsDetail() : $order->getProducts();

        //Set items for intention data
        $items = $this->setItems($products);
        //Set intention data to send to Fpay
        $intentionData = $this->setIntentionData($order, $address, $items);
        //Create payment intention in Fpay
        $this->http->orderId = $order->id;
        $fpayResponse = $this->http->createPaymentIntention($intentionData);
        $redirectUrl = '';
        //Set redirect URL for payment in Fpay
        foreach ($fpayResponse->links as $link) {
            if ($link->rel == "approval_url" && $link->method == "REDIRECT") {
                $redirectUrl = $link->href;
                break;
            }
        }

        //Update prestashop
        $payment = $order->getOrderPaymentCollection()->getFirst();
        $this->updatePaymentTransactionId($payment, $fpayResponse->_id);

        $this->addLog('', true, 'processPayment', 'El usuario será redirigido para realizar el pago con Fpay.');
        $this->logger();
        return $redirectUrl;
    }

    public function updatePaymentTransactionId($payment, string $intentionId)
    {
        if ($payment) {
            $payment->transaction_id = $intentionId;
            $payment->save();
            $this->addLog(
                '',
                false,
                'updatePaymentTransactionId',
                'Se ha actualizado el id de la transacción del pago en prestashop.'
            );
            $this->addLog(json_encode($payment));
        }
    }

    public function processPending()
    {
        $instance = SymfonyContainer::getInstance();
        $router = $instance ? $instance->get('router') : null;
        $adminUrl = $router ? $router->generate("fpay_webhook") : basename(_PS_ADMIN_DIR_) . '/fpay/webhook';
        $url = $this->getSiteUrl(true) . ltrim($adminUrl, '/');
        header("Location: $url&refer=" . urlencode($_SERVER['REQUEST_URI']));
        return true;
    }

    public function getIntention(string $intentionId)
    {
        return $this->http->getIntention($intentionId);
    }

    public function setItems(array $products)
    {
        $items = [];
        foreach ($products as $item) {
            $items[] = [
                "sku" => $item['product_id'],
                "name" => $item['product_name'],
                "description" => $item['product_name'],
                "quantity" => $item['product_quantity'],
                "price" => round($item['price']),
                "tax" => $item['total_price_tax_incl'] - $item['total_shipping_price_tax_excl'],
                "category" => $item['id_category_default']
            ];
        }
        return $items;
    }

    public function getSiteUrl(bool $withoutPrestashop = false)
    {
        $_SERVER['SERVER_PORT'] = isset($_SERVER['SERVER_PORT']) ? $_SERVER['SERVER_PORT'] : 80;
        $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') ||
            $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $domainName = $_SERVER['HTTP_HOST'];

        $baseUrl = $protocol . $domainName . '/';
        $baseUrlPs = _PS_BASE_URL_ . __PS_BASE_URI__;
        if ($withoutPrestashop) {
            return $baseUrl;
        }
        return $baseUrlPs != $baseUrl ? $baseUrlPs : $baseUrl;
    }

    public function setIntentionData(Order $order, Address $address, array $items = [])
    {
        //set response urls for intention data and merchat unique id
        $paymentSuccessUrl = $this->getSiteUrl() .
            "?fc=module&module=fpay&controller=payment&status=success&id=" . $order->id;
        $paymentErrorUrl = $this->getSiteUrl() .
            "?fc=module&module=fpay&controller=payment&status=error&id=" . $order->id;
        $merchantUniqueId = 'ps_' . $order->id . '_' . date('Ymdhisu');
        //post data for Fpay
        $intentionData =  [
            'intention' => 'sale',
            'payment_method' => $this->http->getPaymentMethod(),
            'pst_origen' => $this->http->getPstOrigen(),
            'transaction' => [
                'merchant_unique_id' => $merchantUniqueId,
                'purchase_order' => $order->id,
                'description' => 'Compra PrestaShop',
                'soft_descriptor' => $this->http->getSoftDescriptor(),
                'merchant_fantasy_name' => $this->http->getMerchantFantasyName(),
                'reconciliation_id' => $order->id,
                'invoice_type' => $this->http->getInvoiceType(),
                'terminal_id' => '1',
                'store_id' => '1',
                'channel' => $this->http->getChannel(),
                'on_behalf_of' => $order->id,
                'invoice_number' => $order->id,
                'item_list' => array(
                    'shipping_method' => $this->http->getShippingMethod(),
                    'items' => $items,
                    'shipping_address' => array(
                        "line1" => $address->address1 . " " . $address->address2,
                        "city" => $address->city,
                        "country_code" => $this->http->getCountryCode(),
                        "phone" => $address->phone . " " . $address->phone_mobile,
                        "type" => "HOME_OR_WORK",
                        "recipient_name" => $address->firstname . " " . $address->lastname
                    ),
                ),
                'amount' => array(
                    "currency" => $this->http->getCurrency(),
                    "total" => round($order->total_paid),
                    "details" => array(
                        "subtotal" => round($order->total_products),
                        "tax" => round($order->total_paid_tax_incl - $order->total_paid_tax_excl),
                        "shipping" => round($order->total_shipping),
                        "shipping_discount" => 0
                    )
                )
            ],
            'redirect_urls' => array("return_url" => $paymentSuccessUrl, "cancel_url" => $paymentErrorUrl),
        ];

        $this->addLog('', false, 'intentionData', 'Se ha formateado la información que será enviada a Fpay.');
        $this->addLog(json_encode($intentionData));
        $this->logger();
        return $intentionData;
    }

    public function setOrderStatus(string $fpayState, Order $order, OrderHistory $history)
    {
        $this->http->orderId = $order->id;
        return $this->http->setOrderStatus($fpayState, $order, $history);
    }

    public function refundIntention(Order $order, int $refundedAmount)
    {
        $this->addLog('', true, 'refundIntention', 'Se ha iniciado un proceso de reembolso desde prestashop.');
        $payment = $order->getOrderPaymentCollection()->getFirst();
        $fpayIntention = $this->getIntention($payment ? $payment->transaction_id : '');
        $this->http->orderId = $order->id;
        $merchantUniqueId = 'ps_' . $order->id . '_' . date('Ymdhisu');
        if ($fpayIntention->state === FpayStates::PAID || $fpayIntention->state === FpayStates::PARTIALLY_REFUNDED) {
            $fpayRefundedAmount = $this->getRefundAmount($fpayIntention);
            $refundedAmount = (
                ($refundedAmount + $fpayRefundedAmount) >
                $fpayIntention->transaction->amount->total
            ) ?
                ($refundedAmount - (
                    ($refundedAmount + $fpayRefundedAmount) -
                    $fpayIntention->transaction->amount->total
                )) : $refundedAmount;
            $refundedIntention = $this->http->refundIntention($fpayIntention->_id, $refundedAmount, $merchantUniqueId);
            if (in_array($refundedIntention->state, [FpayStates::PARTIALLY_REFUNDED, FpayStates::REFUNDED])) {
                $this->setOrderStatus(FpayStates::PARTIALLY_REFUNDED, $order, new OrderHistory());
                $this->createMessage($refundedIntention, $order, $refundedAmount);
            }
        }
    }

    public function getRefundAmount($fpayIntention)
    {
        $refundedAmount = 0;
        if (isset($fpayIntention->gateway->resume->refunds)) {
            foreach ($fpayIntention->gateway->resume->refunds as $refund) {
                if ($refund->state == "applied") {
                    $refundedAmount += $refund->refunded_amount;
                }
            }
        }
        return $refundedAmount;
    }

    public function createMessage(
        $fpayIntention,
        Order $order,
        $productAmountAndQuantity,
        array $orderDetail = [],
        string $extraDescription = ''
    ) {
        $date = date('Y-m-d H:i:s', strtotime($fpayIntention->update_time));

        $transactionDetails = "
        Estado: {$fpayIntention->state} \n
        Total: {$fpayIntention->transaction->amount->total} {$fpayIntention->transaction->amount->currency} \n
        Tipo de Pago: {$fpayIntention->payment_method} \n
        Nº de Cuotas: {$fpayIntention->transaction->amount->installments_number} \n
        Fecha: $date \n
        Transacción Nº: {$fpayIntention->_id} \n
        Orden N°: {$fpayIntention->transaction->purchase_order} \n \n" .
            (empty($orderDetail) ? "" : "Producto: " . $orderDetail['product_name'] . "\n \n") .
            (!is_array($productAmountAndQuantity) ? "" : "Cantidad: " . $productAmountAndQuantity[1] . "\n \n") .
            "Monto:" . (!is_array($productAmountAndQuantity) ?
                $productAmountAndQuantity : $productAmountAndQuantity[0]) . "\n
        " . $extraDescription;

        $customerThread = new CustomerThreadCore();
        $customerThread->id_order = $order->id;
        $customerThread->id_customer = $order->id_customer;
        $customerThread->id_lang = 1;
        $customerThread->token = "FPAY-{$order->id}";
        $customerThread->id_contact = 0;
        $customerThread->save();

        $orderMessage = new CustomerMessage();
        $orderMessage->id_order = $order->id;
        $orderMessage->id_customer_thread = $customerThread->id;
        $orderMessage->message = $transactionDetails;
        $orderMessage->private = true;
        $orderMessage->save();
    }

    public function addLog(
        string $data = '',
        bool $currentDate = false,
        string $functionOrVar = '',
        string $description = ''
    ) {
        $this->http->addLog($data, $currentDate, $functionOrVar, $description);
    }

    public function logger()
    {
        $this->http->logger();
    }
}
