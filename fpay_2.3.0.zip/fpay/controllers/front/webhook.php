<?php
require_once _PS_MODULE_DIR_ . 'fpay/vendor/autoload.php';


use GuzzleHttp\Client;
use PrestaShop\Module\Fpay\Classes\FpayGatewayPayment;
use PrestaShop\Module\Fpay\Classes\FpayHttp;


class FpayWebhookModuleFrontController extends ModuleFrontController
{

    /**
     * Initializes common front page content: header, footer and side columns.
     * Process the pending intention of the payment made with Fpay
     *
     * @return void
     */
    public function initContent()
    {
        //Get config fpay
        $config = Configuration::getMultiple(array('FPAY_PRIVATE_KEY', 'FPAY_PUBLIC_KEY'));
        if (!empty($config['FPAY_PUBLIC_KEY'])) {
            $this->publicKey = $config['FPAY_PUBLIC_KEY'];
        }
        if (!empty($config['FPAY_PRIVATE_KEY'])) {
            $this->privateKey = $config['FPAY_PRIVATE_KEY'];
        }
        $fpayGatewayPayment = new FpayGatewayPayment(
            new FpayHttp(new Client(), $this->publicKey, $this->privateKey)
        );
        //start log tracking
        $fpayGatewayPayment->addLog('', true, 'WebHook', 'Se ha iniciado un procesamiento de datos desde Fpay.');
        $data = json_decode(file_get_contents('php://input'));
        $message = "Error al procesar los datos";
        $fpayGatewayPayment->addLog(json_encode($data), false, 'Información recibida desde Fpay');
        if ($data && isset($data->_id)) {
            $intentionId = $data->_id;
            $fpayIntention = $fpayGatewayPayment->getIntention($intentionId);
            if ($fpayIntention && in_array($fpayIntention->pst_origen, ["PrestaShop", "Prestashop", "prestashop"])) {
                //Process pending intention
                $fpayGatewayPayment->addLog(
                    '',
                    false,
                    'processIntention',
                    'Orden recibida desde fpay en procesamiento.'
                );

                $message = $this->processIntention($fpayIntention, $intentionId);
            } else {
                $message = "El origen de la venta no pertenece al comercio.";
            }
        }
        $fpayGatewayPayment->addLog($message);
        $fpayGatewayPayment->logger();
        $this->context->smarty->assign('message', $message);
        $this->setTemplate('module:fpay/views/templates/front/webhook.tpl');
    }

    /**
     * Proccess intention webhook
     *
     * @param [type] $fpayIntention
     * @param string $intentionId
     * @return void
     */
    private function processIntention($fpayIntention, string $intentionId)
    {
        $message = "No se pudo encontrar la orden.\n Está transacción no pertenece a su tienda de prestashop.";
        $order =  new Order($fpayIntention->transaction->purchase_order);
        $payment = $order->getOrderPaymentCollection()->getFirst();
        if ($order->id && $payment && $payment->transaction_id == $intentionId) {
            if (round($order->total_paid) == array_sum(
                array_column($order->getOrderDetailList(), 'total_refunded_tax_incl')
            ) && $order->current_state == _PS_OS_REFUND_) {
                return "Esta orden ya fue reembolsada por completo";
            }
            $db = Db::getInstance();
            $exists = $db->getRow("SELECT `id` FROM `" . _DB_PREFIX_ . "fpay` " .
                "WHERE `intention_id` = '$intentionId' AND `order_id`='$order->id';");
            $message = "La intención de pago ya se encuentra pendiente de actualización";
            if (!$exists) {
                $result = $db->insert('fpay', [
                    'order_id' => (int) $order->id,
                    'intention_id' => pSQL($intentionId)
                ]);
                if ($result) {
                    $message = "La intención de pago se agregó a pendiente de actualización";
                } else {
                    $message = "Hubo un error al insertar en la base de datos, " .
                        "por favor revise la configuración de su servidor.";
                }
            }
        }
        return $message;
    }
}
